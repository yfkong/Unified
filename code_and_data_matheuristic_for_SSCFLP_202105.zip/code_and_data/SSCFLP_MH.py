# -*- coding: utf-8 -*-
## An unified algorithm framework for the Facility Location, Allocation and Service Area Problems. 
## yfkong@henu.edu.cn, Apr.,2020
## to solve problems such as:
## 1 GAP,SAP
## 2 SSCFLP, SSCKFLP, CFLSAP, CKFLSAP
## 3 PMP/CPMP
## 4 PDP
## 5 Eaqul-capacity PMP (ECPMP)


import sys,os,random,time,copy,math,tempfile
#ArcGIS
has_arcpy=0
#mip solver
mip_solvers=[] #MIP solvers supported 
mip_solver=''  #MIP solver, "cplex", "cbc" or ""
mip_file_path=tempfile.gettempdir()
os.chdir(mip_file_path)  #used in arcgis
try:
    import cplex
    #mip_solvers.append('cplex')
except: 
    pass
try:
    import pulp
    s=pulp.apis.GUROBI_CMD()
    if s.available()==False:
        pass
    else:
        mip_solvers.append('gurobi')
    s=pulp.apis.cplex_api.CPLEX_CMD()
    if s.available()==False:
        pass
    else:
        mip_solvers.append('cplex')
    s=pulp.apis.COIN_CMD()
    if s.available()==False:
        pass
    else:
        mip_solvers.append('cbc')
except: 
    pass
if len(mip_solvers)>0: mip_solver=mip_solvers[0]

#constant
MAXNUMBER=1.0e+20
MINNUMBER=1.0e-10
#instance info
nodes=[]
nodes_std=[] #for DP only
num_units=-1
nodedij=[]
nodedik=[]  #weighted cost from i to k, =nodedij*nodes[][3] 
nodendij=[] #network distance
node_neighbors=[]
facility_neighbors=[]
total_pop=0
avg_pop=0
total_supply=0
all_units_as_candadate_locations=1
facilityCandidate=[]
facilityCapacity=[]
facilityCost=[]
num_facilityCandidate=-1
num_districts=-1 # number of service areas/facilities
avg_dis_min=0.0
potential_facilities=[]
NearFacilityList=[]
nearCustomer=[]
nearCustomers=[]
geo_instance=1
pmp_I_eaquls_J=1

#parameters for districting
location_problem=1
max_num_facility=999
adaptive_number_of_facilities=1
fixed_cost_obj=1
spatial_contiguity=1 # 0 no, 1 yes
pop_dis_coeff=10000.0 #used in the objective function
pop_deviation=0.00 #for pdp, 5%

#current solution
centersID=[]
node_groups=[]
district_info=[] #[[0,0,0.0] for x in range(num_districts)] # solution
objective_overload=MAXNUMBER
obj_balance=MAXNUMBER
objective=MAXNUMBER
objective_fcost=MAXNUMBER
biobjective=MAXNUMBER
objective_supply=0.0

given_solution=0 #reserved
all_solutions=[]

#best solution in each start
best_solution =[] # node_groups[:]
best_centersID=[]
best_biobjective=MAXNUMBER
best_objective=MAXNUMBER
best_objective_overload = MAXNUMBER
best_objective_fcost = MAXNUMBER
#global best solution 
#best_centers_global=[]
best_solution_global=[]
best_centersID_global=[]
best_biobjective_global = MAXNUMBER
best_objective_global = MAXNUMBER
best_objective_fcost_global = MAXNUMBER
best_overload_global = MAXNUMBER

#search statistics
time_check=0
time_check_edge_unit=0
time_spp=0.0
time_update_centers=0.0
time_op=[0.0 for x in range(10)]
time_ruin_recreate=[0.0 for x in range(10)]
time_location=[0.0 for x in range(10)]
time_pmp_re_location=0.0
time_repare=0
count_op=[0.0 for x in range(10)]
check_count=0
improved=0
move_count=0

#search histry
region_pool = []
pool_index=[]


#local search
acceptanceRule="hc" #solver name
assignment_operators_selected=[0,1] #0 one-unit move, 1 two-unit move, 2 three-unit move
location_operators_selected=[0,1,2,3,4] #0 swap, 1 drop, 2 add, 3 add+drop, 4 me
ruin_oprators=[0,1,2,3,4] #ruin0, ruin1, 9 mip assign
multi_start_count=6 #population size for GA, ILS, VNS, LIS+VND
initial_solution_method=0 #0 construction, 1 LP
assign_method=0 #not used
assign_or_Location_search_method=0
large_facility_cost=0
maxloops=1000
max_loops_solution_not_improved=-1
SA_maxloops = 100 # maximum number of search loops for GA
SA_temperature=1.0
op_random = 1 # operators used sequentially (0) or randomly(1)
last_loop_obj=0.0
ruin_percentage=20
mainloop=0
mutation_rate=0.01 
cross_methods=-1
adj_pop_loops=5000
solution_similarity_limit=10.0

#mip modelling for inititail solution, spp and full model
is_spp_modeling=1 #0 no spp modelling, 1 modelling at the end, 2 modelling in case of local optimum
linear_relaxation=0
spp_loops=400
solver_time_limit=7200 #used for mip modeling
solver_mipgap=0.000000000001
solver_message=0
heuristic_time_limit=300
seed =random.randint(0,10000)
random.seed(seed)
locTabuLength=100  #nf*psize

def arcpy_print(s):
    if has_arcpy==1: 
        arcpy.AddMessage(s)
    else:
        print s

#record a region in current solution
def update_region_pool(rid):
    global pool_index
    global time_spp
    global region_pool
    t=time.time()
    if is_spp_modeling<=0: return
    if centersID[rid]<0: return
    #if spatial_contiguity==1 and check_continuality_feasibility(node_groups,rid)<1:
    #    return
    ulist=[x for x in  range(num_units) if node_groups[x]==rid]
    if ulist==[]:
        #print "empty area:",rid,node_groups
        return
    cost1=district_info[rid][2]
    cost2=sum(nodedik[x][rid] for x in ulist)
    if abs(cost1-cost2)>0.001: print rid,cost1,cost2
    obj=district_info[rid][2]+district_info[rid][4]*pop_dis_coeff
    idx=rid*100000000+int(obj*10000)
    idx+=sum(x*x for x in ulist)
    if idx not in pool_index[rid]:
        pool_index[rid].append(idx)
        region_pool.append([ulist,district_info[rid][2],district_info[rid][1],district_info[rid][4],rid])
    time_spp+=time.time()-t
    return

#record all regions in current solution
def update_region_pool_all():
    if is_spp_modeling<=0:
        return
    for rid in range (num_districts):
        if centersID[rid]<0: continue
        update_region_pool(rid)
def delete_region_pool_all():
    global region_pool
    global pool_index
    region_pool=[]
    for i in range(num_districts):
        pool_index[i]=[]

#check continuality of a solution (sol)
def check_solution_continuality_feasibility(sol):
    if spatial_contiguity==0: return 2
    feasible = 1
    for i in range (num_districts):
        if centersID[i]<0: continue
        if check_continuality_feasibility(sol,i) <= 0:
            feasible=0  #infeas.
            break
    return feasible
def check_current_solution_continuality_feasibility():
    feaslist=[]
    for i in range (num_districts):
        if centersID[i]<0: continue
        if check_continuality_feasibility(node_groups,i) <= 0:
            feaslist.append(0)
        else: feaslist.append(1)
            
    return feaslist

#check continuality of a region (rid) in solution (sol)
def check_continuality_feasibility(sol,rid):
    global time_check
    global check_count
    if spatial_contiguity==0: return -1
    if geo_instance==0: return -1
    u=facilityCandidate[rid]
    check_count+=1
    t=time.time()
    ulist1=[x for x in range(num_units) if sol[x]==rid and x!=u]
    ulist2=[u]
    #ulist2.append(ulist1.pop())
    for x in ulist2:
        for i in range(len(ulist1)):
            j=ulist1[i]
            if j in node_neighbors[x]:
                ulist2.append(j)
                ulist1[i]=-1
        ulist1=[x for x in ulist1 if x>=0]
    #ulist3=[x for x in ulist1 if x!=-1]
    time_check+=time.time()-t
    if len(ulist1)==0:          
        return 1  #feasible
    return 0    #infeasible

#check continuality of a list of units
def check_ulist_continuality(ulist):
    if spatial_contiguity==0: return 1
    global time_check
    global check_count
    t=time.time()
    ulist1=ulist[:]
    ulist2=[]
    ulist2.append(ulist1.pop())
    check_count+=1
    for x in ulist2:
        for i in range(len(ulist1)):
            #if ulist1[i]==-1: continue
            if ulist1[i] in node_neighbors[x]:
                ulist2.append(ulist1[i])
                ulist1[i]=-1
        ulist1=[x for x in ulist1 if x>=0]         
    #ulist3=[x for x in ulist1 if x!=-1]
    time_check+=time.time()-t
    if len(ulist1)==0:          
        return 1  #feasible
    return 0    #infeasible

#return a list of boundary units
def find_edge_units():
    if spatial_contiguity==0 and random.random()>0.5:
        return find_tail_units()
    ulist=[]
    for x in range(num_units):
        if geo_instance==1 and spatial_contiguity==1 and x in centersID:
            continue  #bug for benckmark instances
        k=node_groups[x]
        for y in node_neighbors[x]:
            if node_groups[y] != k:
                ulist.append(x)
                break
    random.shuffle(ulist)
    if objective_overload==0: 
        return ulist
    ulist=[[x, district_info[node_groups[x]][4]] for x in ulist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[ x[0] for x in ulist]
    return ulist

def find_tail_units():
    #p=1.0
    #nf=sum(1 for x in centersID if x>=0)
    #nu=num_units*1.0/nf
    #if nu>7:
    #    p=(4.0*math.sqrt(nu)-4)/nu
    tlist=[]
    for k in range(num_districts):
        if centersID[k]<0: continue
        ulist=[[x,nodedij[x][k]] for x in range(num_units) if node_groups[x]==k]
        ulist.sort(key=lambda x:-x[1])
        #n=int(len(ulist)*p)
        n=len(ulist)
        if n>7: n=int(4*math.sqrt(n))-4
        if n<1: n=1
        ulist=ulist[:n]
        tlist+=[x[0] for x in ulist]
    random.shuffle(tlist)
    #return tlist 
    if objective_overload==0: #!!!
        return tlist
    #ulist=[ [x, district_info[node_groups[x]][4]] for x in tlist]
    ulist=[[x,nodedij[x][node_groups[x]]*(1+district_info[node_groups[x]][4]*10)] for x in tlist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[ x[0] for x in ulist]
    #print len(tlist)
    return ulist

#return a list of edge units that having three or more neighor regions
def find_edge_units_2():
    ulist=[]
    for x in range(num_units):
        if spatial_contiguity==1 and x in centersID: continue #bug for benckmark instances
        rlist=[node_groups[y] for y in node_neighbors[x]]
        rlist.append(node_groups[x])
        rset=set(rlist)
        if len(rset)>2:
            ulist.append(x)
    random.shuffle(ulist)
    return ulist


#check an edge unit (uid), reserved
def is_edge_unit(uid):
    #global time_check_edge_unit
    if spatial_contiguity==0: return True
    t=time.time()
    rlist = [node_groups[x] for x in node_neighbors[uid]]
    rlist+=node_groups[uid]
    #time_check_edge_unit+=time.time()-t
    if len(set(rlist))==1:
        return False
    return True

#update region information of the current solution
def update_district_info():
    global objective_overload
    global objective
    global biobjective
    global objective_fcost
    global district_info
    global move_count
    global obj_balance
    global centersID
    global objective_supply
    global avg_dis_min
    for k in range(num_districts):
        district_info[k][0] = 0
        district_info[k][1] = 0.0
        district_info[k][2] = 0.0
        district_info[k][3] = 0.0
        district_info[k][4] = 0.0
    for k in range(num_districts):
        if centersID[k]<0 and k in node_groups:
            #arcpy_print("debug: a facility not selected but used: " + str(k))
            centersID[k]=facilityCandidate[k]
        if centersID[k]<0:
            continue
        ulist=[x for x in range(num_units) if node_groups[x]==k]
        if len(ulist)==0:
            if adaptive_number_of_facilities==1:
                supply=sum(facilityCapacity[x] for x in range(num_districts) if centersID[x]>=0)
                #if supply-facilityCapacity[k]>total_pop:
                    #print "deleted unused facility",k,facilityCapacity[k],facilityCost[k]
                centersID[k]=-1
                continue
        district_info[k][0] = len(ulist)
        district_info[k][1] = sum(nodes[x][3] for x in ulist)
        district_info[k][2] = sum(nodedik[x][k] for x in ulist)
        district_info[k][3] = facilityCapacity[k] 
        district_info[k][4] = max(0.0,district_info[k][1]-facilityCapacity[k]) # -district_info[k][3]
        if location_problem==2:
            bal=0.0
            dev=pop_deviation*total_pop/max_num_facility
            if district_info[k][1]>district_info[k][3]+dev: bal=district_info[k][1]-district_info[k][3]-dev
            if district_info[k][1]<district_info[k][3]-dev: bal=district_info[k][3]-district_info[k][1]-dev
            district_info[k][4]=bal
        #print centersID,node_groups
    bal=sum(x[4] for x in district_info)
    objective=sum([x[2] for x in district_info])
    objective_overload=bal
    #if objective/total_pop<avg_dis_min:
    #    avg_dis_min=objective/total_pop
    avg_dis_min=objective/total_pop
    biobjective=objective+objective_overload*avg_dis_min*pop_dis_coeff
    objective_supply=sum(facilityCapacity[x] for x in range(num_districts) if centersID[x] >=0)
    #biobjective=objective+objective_overload*avg_dis_min*1000000
    #biobjective=bal2*avg_dis_min*1000000
    if fixed_cost_obj==1:
        fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x] >=0)
        objective_fcost=fcost
        biobjective+=fcost
    move_count+=1

def find_frag_unit():
    if spatial_contiguity==0: return []
    global time_check_edge_unit
    t=time.time()    
    frag_units=[]
    if spatial_contiguity==2:
        for k in range(num_districts):
            if centersID[k]==-1: continue
            ulist=[x for x in range(num_units) if node_groups[x]==k]
            nflist=frag_unit_minority(ulist)
            frag_units+=nflist
    if spatial_contiguity!=2:
        for k in range(num_districts):
            if centersID[k]==-1: continue
            ulist2=[centersID[k]]
            ulist1=[x for x in range(num_units) if node_groups[x]==k and x!=centersID[k]]
            for x in ulist2:
                for i in range(len(ulist1)):
                    if ulist1[i]==-1: continue
                    if ulist1[i] in node_neighbors[x]:
                        ulist2.append(ulist1[i])
                        ulist1[i]=-1
                ulist1=[x for x in ulist1 if x>=0]
            frag_units+=ulist1

    random.shuffle(frag_units)
    time_check_edge_unit+=time.time()-t
    #print frag_units
    return frag_units    

def frag_unit_minority(ulist):
    final_list=[]
    ulist2=ulist[:1]
    ulist1=ulist[1:]
    while 1:
        for x in ulist2:
            for i in range(len(ulist1)):
                if ulist1[i]==-1: continue
                if ulist1[i] in node_neighbors[x]:
                    ulist2.append(ulist1[i])
                    ulist1[i]=-1
            ulist1=[x for x in ulist1 if x>=0]
        final_list.append([len(ulist2),ulist2[:]])
        if len(ulist1)<=1:
           if len(ulist1)==1:
                final_list.append([1,ulist1[:]])
           break
        u=ulist1[0]
        ulist2=[u]
        del ulist1[0]
    if len(final_list)==1: return []
    final_list.sort(key=lambda x:x[0])
    #del final_list[-1]
    flist=[]
    n=num_units/max_num_facility/10
    for x in final_list: 
        if len(x[1])>n:continue
        flist+=x[1]
    #print [len(flist),len(ulist)],
    return flist

#repare the fragmented solution
def repare_fragmented_solution():
    if spatial_contiguity==0: return
    global node_groups
    global centersID
    global time_repare
    t=time.time()
    for k in range(num_districts):
        if centersID[k]<0: continue
        u=nearCustomer[k]
        node_groups[u]=k
    update_district_info()
    frag_units=find_frag_unit()
    #print "frag_units",frag_units,
    if len(frag_units)==0: return
    sol=node_groups[:]
    for x in frag_units:
        node_groups[x]=-1
    # if location_problem>=3:
        # for k in range(num_districts):
            # if centersID[k]<0: continue
            # if node_groups[k]>=0: continue
            # c,ulist=update_center(k)
            # centersID[k]=-1
            # centersID[c]=c
            # for x in ulist: node_groups[x]=c
    update_district_info()
    #print len(frag_units),
    while len(frag_units)>0:
        newk=-1
        nid=-1
        cost=MAXNUMBER
        for x in frag_units:
            for y in node_neighbors[x]:
                k=node_groups[y]
                if k>=0:
                    gap=max(district_info[k][1]+ nodes[x][3] - facilityCapacity[k],0)
                    if location_problem==3: gap=0
                    cost2=gap*avg_dis_min*pop_dis_coeff + nodedik[x][k]
                    if cost2<cost:
                        nid=x
                        newk=k
                        cost=cost2
        if newk>=0:
            node_groups[nid]=newk
            update_district_info()
            frag_units.remove(nid)
        else:
            break
    #print "frag_units", frag_units
    for x in frag_units:
        node_groups[x]=sol[x]
    #print len(frag_units)
    update_district_info()
    #print check_current_solution_continuality_feasibility()
    time_repare+=time.time()-t

#r&r method
#remove the edge units and reassign them to nearest facilities
def r_r_perb_edge_units():
    global node_groups
    ulist=find_edge_units() 
    num=int(len(ulist)*ruin_percentage/100)
    if num<1: num=1
    ulist=ulist[:num]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()
    if spatial_contiguity>=1: repare_fragmented_solution()

def r_r_large_region():
    global node_groups
    dlist=select_region(-1)
    nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
    num=int(nf*ruin_percentage/100)
    num=max(num,3)
    num=min(num,5)
    dlist=dlist[:num]
    #if len(dlist)>3: dlist=dlist[:3]
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()
    if spatial_contiguity>=1: repare_fragmented_solution()


#r&r method
#remove 1/40 units arround an edge unit
def r_r_perb_location():
    global node_groups
    nf =sum(1 for x in centersID if x>=0)
    ulist=find_edge_units_2()
    if len(ulist)==0:
        ulist=find_edge_units()
    if len(ulist)==0:
        return 
    ulist=[ulist[0]]
    pop=0
    num=int(num_units*ruin_percentage/100)
    #if num<2: num=2
    for x in ulist:
        for y in node_neighbors[x]:
            if y not in ulist:
                ulist.append(y)
        if len(ulist)>=num:
            break
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()
    if spatial_contiguity>=1: repare_fragmented_solution()
def r_r_pathrelink_AP():
    global node_groups
    for i in range(num_units):
        klist=[x[2][i] for x in all_solutions]
        r=random.random()
        idx=int(r*r*0.999*len(klist))
        #idx=random.randint(0,len(klist)-1)
        k=klist[idx]
        node_groups[i]=k    
    update_district_info()
    if spatial_contiguity>=1:
        repare_fragmented_solution()


location_tabu_list=[]
def r_r_new_location(r): #add drop interchange swap/shift(add+drop) 
    global time_location
    global add_not_improved
    global location_tabu_list
    global TB_tabu_list
    if len(location_operators_selected)==0: return -1,0
    nf=sum(1 for x in centersID if x>=0)
    location_operators=location_operators_selected[:]  #[0,1,2,3,4]#[0,1,3,4]
    #minregion=min(x[1] for x district_info if x[0]>0) 
    #if 0 in location_operators and (objective_supply-total_pop)/2 < minregion: location_operators.remove(0)
    idx=r
    if idx<0:
        idx=random.randint(0,len(location_operators)-1)
        idx=location_operators[idx]
    #if adaptive_number_of_facilities==0:
    #    if 1 in location_operators: location_operators.remove(1)
    #    if 2 in location_operators: location_operators.remove(2)
    sta=-1
    t=time.time()
    if idx==0:
        sta=r_r_location_swap_greedy()
        time_location[0]+=time.time()-t
    if idx==1: 
        sta=r_r_location_drop_greedy() 
        time_location[1]+=time.time()-t
    if idx==2: 
        sta=r_r_location_add_greedy()
        time_location[2]+=time.time()-t
    if idx==3: 
        sta=r_r_location_add_greedy()
        RRT_local_search()
        sta=r_r_location_drop_greedy() 
        time_location[3]+=time.time()-t
    if idx==4: 
        sta=r_r_reselect_location_univ()
        time_location[4]+=time.time()-t
    if idx==5: 
        sta=r_r_reselect_location_pmp()
        time_location[5]+=time.time()-t
    if idx==7: 
        sta=pmp_TB()
        time_location[7]+=time.time()-t
        if sta<=0: sta=-9
    if idx==8: #mip location search 
        obj=biobjective
        sta=MIP_PMP_location_search()
        if biobjective>obj-0.00000001:
            TB_tabu_list.append(centersID)
        if spatial_contiguity>=1:
            repare_fragmented_solution()
        time_location[8]+=time.time()-t
    if idx==9: #mip location search 
        #print check_current_solution_continuality_feasibility()
        sta=MIP_location_search()
        time_location[9]+=time.time()-t
        if spatial_contiguity>=1:
            repare_fragmented_solution()
            #print check_current_solution_continuality_feasibility()
    if centersID not in location_tabu_list:
        location_tabu_list.append(centersID[:])
    #if sta==1: VND_local_search()
    return idx,sta
def r_r_location_add_greedy():
    global centersID
    global node_groups
    if adaptive_number_of_facilities==0: return 0
    clist=[x for x in range(num_districts) if centersID[x]<0]# and x in potential_facilities]
    if len(clist)==0: return 0
    addlist=[]
    for nk in clist:
        ids=centersID[:]
        ids[nk]=facilityCandidate[nk]
        if locations_exist(ids)==1: continue
        if ids in location_tabu_list: continue
        ulist=[[x,nodedij[x][nk]] for x in range(num_units) if nodedij[x][nk]<nodedij[x][node_groups[x]]]
        #ulist=[[x,nodedik[x][node_groups[x]]-nodedik[x][nk]] for x in range(num_units) if nodedik[x][node_groups[x]]>nodedik[x][nk]]
        ulist.sort(key=lambda x:x[1])
        savings=0.0
        if fixed_cost_obj==1: savings=-facilityCost[nk]
        ndemand=0
        nsupply=facilityCapacity[nk]
        for x,y in ulist:
            #if nk==0: print savings, 
            if ndemand+nodes[x][3]<=nsupply:
                ndemand+=nodes[x][3]
                savings+=nodedik[x][node_groups[x]]-nodedik[x][nk] #*nodes[x][3]
        #if nk==0: print "addeval", nk,savings
        if savings<-0.02*biobjective: continue
        addlist.append([nk,savings,copy.deepcopy(ulist)])
    if len(addlist)==0: return 0
    addlist.sort(key=lambda x:-x[1])
    if len(addlist)==0: return 0
    if addlist[0][1]>=0:
        while addlist[-1][1] <0:
            addlist.pop()

    #print "add", [ addlist[x][1] for x in range(min(len(addlist),5))]
    #print [ [x[0],x[1],facilityCost[x[0]]] for x in addlist]
    r=random.random()
    idx=int(r*r*0.999*min(3,len(addlist)/2))
    #idx=0
    k=addlist[idx][0]
    centersID[k]=facilityCandidate[k]
    ulist=addlist[idx][2]
    #for x,y in ulist: print "u", x, nodedij[x][node_groups[x]], nodedij[x][k],nodedik[x][node_groups[x]], nodedik[x][k],nodedik[x][node_groups[x]]-nodedik[x][k]
    #print "add", idx,k,addlist[idx][1]
    ndemand=0
    nsupply=facilityCapacity[k]
    if spatial_contiguity>=1:
        u=nearCustomer[k]
        node_groups[u]=k
        ndemand+=nodes[u][3]
    for x,y in ulist:
        if ndemand+nodes[x][3]<=nsupply:
            ndemand+=nodes[x][3]
            node_groups[x]=k
    #print "add", addlist[idx][1],[biobjective,objective,objective_overload],
    update_district_info()
    #print "add",addlist[idx][1],biobjective,ulist
    if spatial_contiguity>=1: repare_fragmented_solution()
    return 1


def r_r_location_drop_greedy(): #tested?
    global centersID
    global node_groups
    if adaptive_number_of_facilities==0: return 0
    if objective_supply<total_pop: 
        #print "drop objective_supply<total_pop: ", objective_supply 
        return 0
    dlist=[]
    clist=[x for x in range(num_districts) if centersID[x]>=0 and objective_supply-facilityCapacity[x]>=total_pop]
    if clist==[]: return 0
    for k in clist:
        ids=centersID[:]
        ids[k]=-1
        if locations_exist(ids)==1: continue
        if ids in location_tabu_list: continue
        ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x]==k]
        ulist.sort(key=lambda x:-x[1])
        savings=district_info[k][2]
        if fixed_cost_obj==1: savings+=facilityCost[k]
        caplist=[facilityCapacity[x]-district_info[x][1] for x in range(num_districts)]
        caplist[k]=0
        for x,y in ulist:
            assigned=0
            for r in NearFacilityList[x]:
                if centersID[r]<0: continue
                if r==k: continue
                if y<=caplist[r]:
                    savings-=nodedik[x][r]
                    caplist[r]-=y
                    assigned=1
                    break
            if assigned==0:
                for r in NearFacilityList[x]:
                    if centersID[r]<0: continue
                    if r==k: continue
                    #if caplist[r]<=0: continue
                    savings-=nodedik[x][r]
                    caplist[r]-=y
                    break
        surplus=sum(x for x in caplist if x <0) #negitive
        if surplus<-district_info[k][1]*0.05: continue
        savings+=surplus*avg_dis_min*5
        if savings<-biobjective*0.02: continue
        dlist.append([k,savings])
    if len(dlist)==0: return 0 #fail
    dlist.sort(key=lambda x:-x[1])
    if dlist[0][1]>0:
        while dlist[-1][1]<0: dlist.pop()
    r=random.random()
    idx=int(r*r*0.999*min(5,len(dlist)))
    k=dlist[idx][0]
    centersID[k]=-1
    
    ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x]==k]
    ulist.sort(key=lambda x:-x[1])
    caplist=[district_info[x][3]-district_info[x][1] for x in range(num_districts)]
    caplist[k]=0
    for x,y in ulist:
        assigned=0
        for r in NearFacilityList[x]:
            if centersID[r]<0: continue
            if y<=caplist[r]:
                caplist[r]-=y
                node_groups[x]=r
                assigned=1
                break
        if assigned==0:
            for r in NearFacilityList[x]:
                if centersID[r]<0: continue
                caplist[r]-=y
                node_groups[x]=r
                break
    #ulist=[x for x in range(num_units) if node_groups[x]==k]
    #for x in ulist:
    #    for k in NearFacilityList[x]:
    #        if centersID[k]>=0:
    #            node_groups[x]=k
    #            break
    update_district_info()
    #print "drop",dlist[idx][1],[biobjective,objective,objective_overload]
    if spatial_contiguity>=1: repare_fragmented_solution()
    return 1

def select_region(seed):
    nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
    n=100*nf/num_units  #areas with 100 units
    if nf<=5: n=nf
    #if nf>=7: n=random.randint(nf/2+1,nf)
    if nf>=6 and nf<=11: n=random.randint(nf/2+1,9)
    if nf>=12 and nf<=16: 
        n=random.randint(7,10)
    if nf>=17: 
        n=random.randint(7,10)
    if n*num_units/nf<80: 
        n=min(10,80*nf/num_units)
    #clist=[]
    #u=random.randint(0,num_units-1)
    #if r>=0: 
    #    u=nearCustomer[r]
    #    clist=[r]
    #for k in NearFacilityList[u]:
    #    if centersID[k]<0: continue
    #    if k not in clist: clist.append(k)
    #    if len(clist)==n: break
    #return clist
    #if objective_overload>0: ???
    u=seed
    if u<0: u=random.randint(0,num_units-1)
    r=node_groups[u]
    if location_problem==0 and objective_overload>0: #SAP
        rlist=[k for k in range(num_districts) if district_info[k][4]>0]
        random.shuffle(rlist)
        r=rlist[0]
        u=nearCustomer[r]
        return NearFacilityList[u][:n]

    clist=[r]
    if random.random()>-0.5:
        for k in NearFacilityList[u]:
            if centersID[k]<0: continue
            if k==r: continue
            clist.append(k)
            if len(clist)==n: break
        #clist.sort()
        return clist

    for i in facility_neighbors[r]:
        if centersID[i]<0: continue
        clist.append(i)
        if len(clist)>=n: break
    #clist.sort()
    return clist

def locations_exist(ids):
    exist=0
    for x in all_solutions:
        if ids==x[1]:
            exist=1
            break
    return exist

def r_r_location_swap_greedy():#tested
    ##bug: a far-and-cheap location will be selected
    global centersID
    global node_groups
    dnlist=[]
    klist=[x for x in range(num_districts) if centersID[x]>=0]
    clist=[x for x in range(num_districts) if centersID[x]<0 and x in potential_facilities]
    if clist==[]: return 0	
    supply=sum(facilityCapacity[x] for x in klist)
    random.shuffle(klist)
    random.shuffle(clist)
    location_tabu=[]
    for k in klist:
        #ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x]==k]
        #ulist.sort(key=lambda x: -x[1])
        #ulist=[x[0] for x in ulist]
        ulist=[x for x in range(num_units) if node_groups[x]==k]
        findswap=0
        for j in clist:
            if objective_supply-facilityCapacity[k] +facilityCapacity[j]<min(objective_supply,total_pop): continue
            ids=centersID[:]
            ids[k]=-1
            ids[j]=facilityCandidate[j]
            if ids in location_tabu_list: continue
            #if locations_exist(ids)==1: continue
            savings=district_info[k][2]
            savings-=sum(nodedik[x][j] for x in ulist)
            if facilityCapacity[j] <facilityCapacity[k]:
                savings-=(facilityCapacity[k]-facilityCapacity[j])*avg_dis_min*2
            if fixed_cost_obj==1:
                savings+=facilityCost[k] - facilityCost[j]
            if savings>biobjective*0.0005 and facilityCapacity[j] >=facilityCapacity[k]:
                dnlist=[[k,j,savings]]
                findswap=1
                break
            if savings< -biobjective*0.02: continue
            dnlist.append([k,j,savings])
        if len(dnlist)>20: break
        if findswap==1: break
    if len(dnlist)==0: return 0
    dnlist.sort(key=lambda x: -x[2]) 
    #if dnlist[0][2]>0:
    #    while dnlist[-1][2]<0: dnlist.pop()	

    r=random.random()
    idx=int(r*r*0.999*min(5,len(dnlist)))
    #print [len(dnlist),idx,dnlist[idx][2] ]
    dk=dnlist[idx][0]
    nk=dnlist[idx][1]
    #print "swap",dnlist[idx][0],dnlist[idx][1],dnlist[idx][2]
    #print district_info[dk]
    #---------------assignment 
    centersID[dk]=-1
    centersID[nk]=facilityCandidate[nk]
    district_info[nk][1]=0
    district_info[nk][3]=facilityCapacity[nk]
    ulist=[x for x in range(num_units) if node_groups[x]==dk]
    for x in ulist: node_groups[x]=nk
    
#    ulist=[[x,nodedij[x][nk]] for x in range(num_units) if node_groups[x]==dk]
#    ulist.sort(key=lambda x:x[1])
#    for x,y in ulist:
#        node_groups[x]=-1
#        for r in NearFacilityList[x]:
#            if centersID[r]<0: continue
#            if y<=district_info[r][3]-district_info[r][3]:
#                node_groups[x]=r
#                district_info[r][3]
#                break
#    ulist=[x for x in range(num_units) if node_groups[x]==-1]
#    for x in ulist:
#        for r in NearFacilityList[x]:
#            if centersID[r]<0: continue
#            node_groups[x]=r
#            district_info[r][3]
#            break
    #print dnlist
    #print "swap",dnlist[idx][2],[biobjective,objective,objective_overload],
    #reassign([dk],[nk])
    update_district_info()
    #print district_info[nk]

    #print "swap", dnlist[idx][2],[biobjective,objective,objective_overload]
    #print sum(nodedik[x][dk] for x in ulist),sum(nodedik[x][nk] for x in ulist)
    if spatial_contiguity>=1: repare_fragmented_solution()
    return 1

def r_r_reselect_location_univ():
    global centersID
    global node_groups
    numf=sum(1 for x in centersID if x>=0)
    used_facilities=potential_facilities[:]
    dlist=select_region(-1)
    clist=dlist[:]
    #if random.random()>0.5: del clist[0]
    ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x] in dlist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[x[0] for x in ulist] #debug
    flist=[[x, max_exclusion_list[x]] for x in range(num_districts) if centersID[x]<0 and nearCustomer[x] in ulist and max_exclusion_list[x] <= biobjective]
    #flist=[[x, max_exclusion_list[x]] for x in range(num_districts) if centersID[x]<0 and nearCustomer[x] in ulist]
    if random.random()>0.5:
        flist.sort(key=lambda x:x[1])
    else: random.shuffle(flist)	
    #if len(flist)>numf*3: flist=flist[:numf*3]
    flist=[x[0] for x in flist]
    if location_problem==2 or num_units==len(facilityCandidate):
        flist=[]
        for x in dlist:
            flist+=node_neighbors[x]
        random.shuffle(flist)
    #clist=list(set(clist+flist))
    maxcand=len(flist)
    if len(dlist)>=8:maxcand=len(dlist)*2
    if len(dlist)==7:maxcand=14#16 #14 #c15,7=6423
    if len(dlist)==6:maxcand=15#15  #c16,6=8008
    if len(dlist)==5:maxcand=16#16 #c16,5=4368
    if len(dlist)<5:maxcand=17#17 #c16,4=1820
    #if maxcand <len(flist)/3: maxcand=len(flist)/3
    for x in flist:
        if x not in clist: clist.append(x)
        if len(clist)>=maxcand: break

    demand=sum(district_info[x][1] for x in dlist)
    old_dis=sum(district_info[x][2] for x in dlist)
    old_supply=sum(district_info[x][3] for x in dlist)
    old_cost=sum(facilityCost[x] for x in dlist)
    dlist.sort()
    try_count=0
    maxcount=1
    n=len(clist)
    m=len(dlist)
    for i in range(m):
        maxcount*=1.0*(n-i)/(i+1)
    if adaptive_number_of_facilities==1:
        p=1.0
        for i in range(m-1):
            p*=1.0*(n-i)/(i+1)
        maxcount+=p
        p=1.0
        for i in range(m+1):
            p*=1.0*(n-i)/(i+1)
        maxcount+=p
    if maxcount>10000: 
        maxcount=10000
        #nlist=CLF_part_LR_main(len(dlist)+adddrop,dlist,old_cost+old_dis)
        #for x in dlist: centersID[x]=-1
        #for x in nlist: centersID[x]=facilityCandidate[x]
        #reassign(dlist,nlist)
        #if spatial_contiguity==1: repare_fragmented_solution()
        #return 1 
    mc_cand=[]
    locations_tabu=[]
    check_flag=0#random.random()
    improve=0
    #is_drop_search=-1
    #minregion=min(x[1] for x in district_info if x[1]>0)
    #if objective_supply-total_pop <minregion:  is_drop_search=0
    addlist=[-1,0,1]
    #assign_evluation=random.randint(0,1)
    while 1:
        try_count+=1
        if try_count>=maxcount:
            break
        random.shuffle(clist)
        nf=len(dlist)
        if adaptive_number_of_facilities==1:
            random.shuffle(addlist)
            nf+=addlist[0]
            #if new_supply-facilityCapacity[nlist[-1]]>=min(demand,old_supply):
            #    nlist=clist[:nf-1]
            #elif new_supply>=min(demand,old_supply):
            #    nlist=clist[:nf]
            #else:
            #    nlist=clist[:nf+1]
            #new_supply=sum(facilityCapacity[k] for k in nlist)
        nlist=clist[:nf]
        new_supply=sum(facilityCapacity[k] for k in nlist)
        if new_supply<min(demand,old_supply): continue
        #nlist.sort()
        list1=[x for x in dlist if x not in nlist]
        list2=[x for x in nlist if x not in dlist]
        if len(list1)>min(3,len(dlist)/2): continue
        if len(list2)>min(3,len(dlist)/2): continue
        #if 0 in location_operators_selected and len(list1)==1 and len(list2)==1: continue #swap
        #if 1 in location_operators_selected and len(list1)>=1 and len(list2)==0: continue #drop
        #if 2 in location_operators_selected and len(list1)==0 and len(list2)>=0: continue #add
        #if len(list2)==0: continue
        if len(list1)+len(list2)==0: continue
        if abs(len(list1)-len(list2))>2: continue
        #if len(set(dlist+nlist))<=len(dlist)+1: continue #no drop, add, and swap,

        #if objective_supply+new_supply-old_supply< min(total_pop,objective_supply): continue
        ids=centersID[:]
        for x in dlist: ids[x]=-1
        for x in nlist: ids[x]=facilityCandidate[x]
        if locations_exist(ids)==1: continue
        if ids in location_tabu_list: continue
        if nlist in locations_tabu: continue
        #if assign_evluation==1:
        #    ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x] in list1]
        #    ulist.sort(key=lambda x:-x[1])
        #    ulist=[x[0] for x in ulist] #reassign part of units

        list1=dlist	#reassign all units
        list2=nlist

        savings=sum(district_info[x][2] for x in list1)
        old_dis=sum(district_info[x][2] for x in list1)
        if fixed_cost_obj==1:
            savings+=sum(facilityCost[x] for x in list1)
            savings-=sum(facilityCost[x] for x in list2)
        caplist=[district_info[x][3]-district_info[x][1] for x in range(num_districts)]
        for x in list1: caplist[x]=0
        for x in list2: caplist[x]=facilityCapacity[x]
        surplus=0
        tcost=0.0
        sol=[]
        supply2=sum(caplist)
        #if assign_method==1:  savings-=reassign(list1,list2) 
        if assign_method>=0:#!=1:  #assign_method not used
            eulist=ulist
            if len(list2)>1:
                udiff=[]
                for x in ulist:
                    klist=[k for k in NearFacilityList[x] if k in list2]
                    k1=klist[0]
                    k2=klist[1]
                    udiff.append([x,nodedij[x][k1]-nodedij[x][k2]])
                udiff.sort(key=lambda x:x[1])
                eulist=[x[0] for x in udiff]
            for x in eulist:
                assigned=0
                for r in NearFacilityList[x]:
                    if nodes[x][3]<=caplist[r]:
                        savings-=nodedik[x][r]
                        caplist[r]-=nodes[x][3]
                        tcost+=nodedik[x][r]
                        sol.append([x,r])
                        assigned=1
                        break
                if assigned==0: 
                    for r in NearFacilityList[x]:
                        if r not in nlist: continue
                        savings-=nodedik[x][r]
                        caplist[r]-=nodes[x][3]
                        tcost+=nodedik[x][r]
                        sol.append([x,r])
                        break
            surplus=sum(x for x in caplist if x <0) #negitive
            savings+=surplus*avg_dis_min*2
        #print [len(list1),len(list2),old_supply,new_supply,supply2,int(savings),surplus]
        #if surplus < -demand*0.03: continue
        if savings < -biobjective*0.0001: continue
        if savings>0: improve+=1
        if savings>0.0001 and surplus>=0:
            mc_cand=[[savings,nlist[:],copy.deepcopy(sol),surplus]]
            break
        locations_tabu.append(nlist)
        mc_cand.append([savings,nlist[:],copy.deepcopy(sol),surplus])
        
        #if improve>=5: break
    #---------------assignment 
    if len(mc_cand)==0: return 0
    mc_cand.sort(key=lambda x:-x[0])
    r=random.random()
    idx=int(r*r*0.999*min(5,len(mc_cand)))
    #idx=0
    nlist=mc_cand[idx][1]
    for x in dlist: centersID[x]=-1
    for x in nlist: centersID[x]=facilityCandidate[x]
    old_overload=objective_overload

    #reassign(dlist,nlist)
    sol=mc_cand[idx][2]
    for i,k in sol: node_groups[i]=k
    update_district_info()

    list1=[x for x in dlist if x not in nlist]
    list2=[x for x in nlist if x not in dlist]
    #print "me", [len(dlist),len(clist),len(dlist)+len(flist),len(ulist)],list1,list2,[len(mc_cand),idx,mc_cand[idx][0],mc_cand[idx][-1]],biobjective,objective_overload
    if spatial_contiguity>=1: repare_fragmented_solution()
    return 1 

def reassign_geo(dlist,nlist):
    global node_groups
    if spatial_contiguity>=1:
        ulist=[x for x in range(num_units) if node_groups[x] in dlist]
        for x in ulist: node_groups[x]=-1
        for x in ulist:
            for k in NearFacilityList[x]:
                if centersID[k]<0: continue
                node_groups[x]=k
                break
        update_district_info()
        return

    ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x] in dlist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[x[0] for x in ulist]
    for x in ulist: node_groups[x]=-1
    for x in nlist: 
        district_info[x][1]=0
        district_info[x][3]=facilityCapacity[x]

    for x in ulist:
        for k in NearFacilityList[x]:
            #if k not in nlist: continue
            if centersID[k]<0: continue
            if district_info[k][1]+nodes[x][3]<=district_info[k][3]:
                node_groups[x]=k
                district_info[k][1]+=nodes[x][3]
                break
    ulist=[x for x in ulist if node_groups[x]<0]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]<0: continue  
            #if k not in nlist: continue
            node_groups[x]=k
            break
    update_district_info()

def reassign(dlist,nlist):
    global node_groups
    if spatial_contiguity>=1:
        return reassign_geo(dlist,nlist)
    ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x] in dlist and node_groups[x] not in nlist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[x[0] for x in ulist]
    for x in ulist: node_groups[x]=-1
    for x in nlist: 
        if x in dlist and x in nlist: continue 
        if x in dlist and x not in nlist: 
            district_info[x][1]=0
            district_info[x][3]=0
        if x not in dlist and x in nlist: 
            district_info[x][1]=0
            district_info[x][3]=facilityCapacity[x]

    for x in ulist:
        for k in NearFacilityList[x]:
            if k not in nlist: continue
            if centersID[k]<0: continue
            if district_info[k][1]+nodes[x][3]<=district_info[k][3]:
                node_groups[x]=k
                district_info[k][1]+=nodes[x][3]
                break
    ulist=[x for x in ulist if node_groups[x]<0]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]<0: continue  
            node_groups[x]=k
            break
    update_district_info()

#r&r method
#assign the removed units to solution
def repare_partial_solution():
    global node_groups
    #if spatial_contiguity!=1:
    #    repare_partial_solution_nonconnectivity()
    #    return
    ulist=[x for x in range(num_units) if node_groups[x]==-1] # units not assigned
    for x in ulist:
        d=MAXNUMBER
        k=-1
        for y in range(num_districts):
            if centersID[y]<0: continue
            if nodedik[x][y]<d:
                d=nodedik[x][y]
                k=y
        node_groups[x]=k
    update_district_info()
  
#r&r method
#ruin a region and recreate it
def r_r_perb_district():
    nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
    num=int(nf*ruin_percentage/100)
    if num<1: num=1
    for i in range(num): r_r_perb_a_district()
    update_district_info()
    if spatial_contiguity>=1: repare_fragmented_solution()	
def r_r_perb_a_district():
    global node_groups
    k=random.randint(0, num_districts-1)
    while centersID[k]<0:
        k=random.randint(0, num_districts-1)
    ulist=[x for x in range(num_units) if node_groups[x]==k]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()

def r_r_perb_mutation():
    global node_groups
    rate=ruin_percentage
    ulist=find_edge_units()
    nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
    #num=int(num_units*rate)
    num=nf/2
    #if location_problem==3: num=max(5,nf/4)

    if num<1: num=1
    for x in ulist:
        if node_groups[x]==x and location_problem==3: continue
        for y in node_neighbors[x]:
            if node_groups[x]!=node_groups[y]:
                node_groups[x]=node_groups[y]
                num-=1
                break
        if num<=0:
            break
    update_district_info()
    #if spatial_contiguity>=1: repare_fragmented_solution()

#update the best and the global best solution
#if the current solution is better than the best
def update_best_solution():
    global best_solution
    global best_centersID
    global best_biobjective
    global best_objective
    global best_objective_fcost
    global best_overload
    global best_objective_overload
    global best_centersID_global
    global best_solution_global
    global best_biobjective_global
    global best_objective_global
    global best_objective_fcost_global
    global best_overload_global    
    global improved_loop
    global improved
    global avg_dis_min
    improve =0
    if location_problem==1 and adaptive_number_of_facilities==0:
        nf=sum(1 for x in centersID if x>=0)
        if nf!=max_num_facility: return 0
    #if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
    #    ##noprint "check_solution_continuality_feasibility!!!"
    #    return improve
    biobj=biobjective
    biobj_best=best_biobjective
    if biobj<=biobj_best:
        best_biobjective=biobj
        best_objective = objective
        best_objective_fcost=objective_fcost
        best_objective_overload = objective_overload
        best_solution = node_groups[:]
        best_centersID=centersID[:]
        improved_loop=mainloop
        improve =1
        improved+=1
    if biobj<best_biobjective_global:
        best_biobjective_global=biobj
        best_centersID_global=centersID[:]
        best_overload_global = objective_overload
        best_solution_global =node_groups[:]
        best_objective_global = objective
        best_objective_fcost_global=objective_fcost
        avg_dis_min=biobj/total_pop
    return improve

def region_neighbors(rid):
    if geo_instance==0:
        return region_neighbors2(rid) #for benchmark instance
    ulist=[x for x in range(num_units) if node_groups[x]==rid]
    rlist=[]
    for x in ulist:
        for y in node_neighbors[x]:
            k=node_groups[y]
            if k==rid: continue
            if k not in rlist: rlist.append(k)
    if rid in rlist: rlist.remove(rid)
    random.shuffle(rlist)
    return rlist

def region_neighbors2(rid):
    ulist=[x for x in range(num_units) if node_groups[x]==rid]
    clist=[[x,MAXNUMBER] for x in range(num_districts) if centersID[x]>=0 and x!=rid]
    for i in range(len(clist)):
        k=clist[i][0]
        clist[i][1]=min(nodedij[x][k] for x in ulist)
    clist.sort(key=lambda x:x[1])
    #print clist
    rlist=[x[0] for x in clist if x[1]<=3*search_radius]
    rlist=rlist[:6]
    random.shuffle(rlist)
    k=min(6,len(rlist)-1)
    #print len(rlist),search_radius
    return rlist

#return the neighor regions of unit nid
def neighbor_regions(nid):
    rid=node_groups[nid]
    if spatial_contiguity>=1:
        rlist2=[node_groups[x] for x in node_neighbors[nid] if node_groups[x]!=rid]
        rlist=list(set(rlist2))
        if len(rlist2)>1: random.shuffle(rlist2)
        return rlist
    if spatial_contiguity>=0 and random.random()>0.5: #testing ??? 
        knn=4
        #if knn< num_units/100: knn=num_units/100
        rlist=[]
        for k in NearFacilityList[nid]:
            if k==rid: continue
            if centersID[k]<0: continue
            rlist.append(k)
            if len(rlist)>=knn: break 
        return rlist
    rlist2=[node_groups[x] for x in node_neighbors[nid] if node_groups[x]!=rid]
    rlist=list(set(rlist2))
    if len(rlist2)>1: random.shuffle(rlist2)
    return rlist

#evaluate the possible moves
#return 0 or 1 according to the acceptance rule
#acceptance rule: sa, rrt, oba or others
def isbetter(obj_old,obj_new,bal_old,bal_new):
    #fixed cost is not considered
    penalty=avg_dis_min*pop_dis_coeff
    biobj_new=objective-obj_old+obj_new+bal_new*penalty
    biobj_old=objective+objective_overload*penalty
    if biobj_new<biobj_old-0.000001: #better
        return 1
    if bal_new>bal_old: return 0 #more overload, or not reduce the overload
    if acceptanceRule=="rrt":
        if objective+obj_new-obj_old-best_objective<best_objective*1.0/num_units:
            if random.random()>0.5: return 0
            else: 
                #print ".",
                return 1
    if acceptanceRule=="sa":
        #minobj=min(last_loop_obj,biobjective)
        #a=-(biobj_new-minobj)/minobj*num_units/SA_temperature
        a=-(objective+obj_new-obj_old-best_objective)/best_objective*num_units/SA_temperature
        if a>=0: return 1
        p=math.exp(a)
        if random.random()< p:  return 1
    return 0

def one_unit_move(): #FA
    global node_groups
    global time_op
    global count_op
    if spatial_contiguity>=1:
        return one_unit_move_geo()
    t=time.time()
    ulist=find_edge_units()
    difflist=[]
    for x in ulist:
        rlist=[r for r in NearFacilityList[x] if centersID[r]>=0]
        k=node_groups[x]
        difflist.append([x,nodedik[x][rlist[0]]-nodedik[x][k]])
    difflist.sort(key=lambda x:x[1])
    ulist=[x[0] for x in difflist]
    find_best_solution=0
    for nid in ulist:
        rid=node_groups[nid]
        demand=nodes[nid][3]
        klist=neighbor_regions(nid)
        if len(klist)>1:
            klist2=[x for x in NearFacilityList[nid] if x in klist]
            klist=klist2
        for k in klist:
            #if k==rid: print "k==rid", nid,rid,neighbor_regions(nid)
            if demand+district_info[k][1]>facilityCapacity[k]: continue
            savings=nodedik[nid][rid]-nodedik[nid][k]
            overload_old=district_info[rid][4]+district_info[k][4]
            overload_new= max(0,district_info[rid][1]-nodes[nid][3]-facilityCapacity[rid]) +max(0,district_info[k][1]+nodes[nid][3]-facilityCapacity[k])
            savings+= (overload_old-overload_new)*avg_dis_min*pop_dis_coeff
            if savings<=0: continue
            node_groups[nid]=k
            count_op[0]+=1
            #print "OUM",best_savings,biobjective,objective,objective_overload,
            update_district_info()
            #print "->",biobjective,objective,objective_overload
            find_best_solution += update_best_solution()
            break
    if spatial_contiguity>=1: repare_fragmented_solution()
    time_op[0]+=time.time()-t
    return find_best_solution

#move one edge unit to its neighbor region
def one_unit_move_geo():
    #global district_info
    global node_groups
    global time_op
    global count_op
    popa=total_pop*1.0/max_num_facility #location_problem==2
    dev=pop_deviation*popa
    
    t=time.time()
    improve = 0
    ulist=find_edge_units()
    find_best_solution=0
    for n1 in ulist:
        k1 = node_groups[n1]
        for k2 in neighbor_regions(n1):
            obj_new = nodedik[n1][k2]
            obj_old = nodedik[n1][k1]
            old_bal=district_info[k1][4]+district_info[k2][4]
            new_pop1=district_info[k1][1]-nodes[n1][3]
            new_pop2=district_info[k2][1]+nodes[n1][3]
            new_bal=max(0,new_pop1-facilityCapacity[k1]) + max(0,new_pop2-facilityCapacity[k2])
            if location_problem==2: 
                new_bal=0.0
                if new_pop1 >popa+dev: new_bal+=new_pop1-popa-dev
                if new_pop2 >popa+dev: new_bal+=new_pop2-popa-dev
                if new_pop1 <popa-dev: new_bal+=popa-dev-new_pop1
                if new_pop2 <popa-dev: new_bal+=popa-dev-new_pop2
            #if isbetter(obj_old,obj_new,old_bal,new_bal)==0:
            if isbetter(obj_old,obj_new,objective_overload,objective_overload-old_bal+new_bal)==0:
                continue
            sol=node_groups[:]
            sol[n1] = k2
            if spatial_contiguity>=1 and check_continuality_feasibility(sol,k1)==0:
                break
            count_op[0]+=1
            node_groups[n1] = k2
            obj=biobjective
            objb=best_objective
            #print [1,obj_old,obj_new,old_bal,new_bal,biobjective,avg_dis_min],
            update_district_info()
            #print biobjective
            #if objective-obj> obj_new-obj_old+0.01:
            #     print "debug oum!!!"
            #if biobjective>obj and objective>objb*(1+0.5/num_units)+0.001:
            #    print "debug oum move with threshold!!!",obj_old,obj_new,old_bal,new_bal,obj,biobjective,objb
            find_best_solution += update_best_solution()
            break
    time_op[0]+=time.time()-t
    return find_best_solution
    global node_groups
    global time_op
    global count_op
    improved = 0
    t=time.time()
    while 1:
        improve = 0
        #if spatial_contiguity==0:
        ulist=find_edge_units()
        for u in ulist:
            k=node_groups[u]
            for u2 in node_neighbors[u]:
                if node_groups[u2]==k: continue
                k2=node_groups[u2]
                if nodedik[u][k2]>nodedik[u][k]: continue
                #if spatial_contiguity==1: 
                #    ulist2=[x for x in range(num_units) if node_groups[x]==k and x!=u]
                #    if ulist2==[]: continue
                #    if check_ulist_continuality(ulist2)==0: continue
                node_groups[u] = k2
                improve+=1
                improved=1
        if improve == 0: break
        update_district_info()
        #update_best_solution()
        #break
    time_op[0]+=time.time()-t
    return improved
def two_unit_move():
    if spatial_contiguity==1 or location_problem==2:
        return two_unit_move_geo()
    global node_groups
    global time_op
    global count_op
    t=time.time()
    find_best_solution=0
    improve = 0
    ulist=find_edge_units()
    difflist=[]
    for x in ulist:
        rlist=[r for r in NearFacilityList[x] if centersID[r]>=0]
        k=node_groups[x]
        difflist.append([x,nodedij[x][rlist[0]]-nodedij[x][k]])
    if len(difflist)==0:
        print "debug: two_unit_move(): len(difflist)==0"
    difflist.sort(key=lambda x:x[1])
    ulist=[x[0] for x in difflist]
    nu=len(ulist)/2
    fulist=ulist[:nu]
    movelist =[]
    for n1 in ulist:
        k1 = node_groups[n1]
        rlist1=neighbor_regions(n1)
        success_move=0
        ulist2=[x for x in ulist if node_groups[x] in rlist1]
        random.shuffle(ulist2)
        for n2 in ulist2:
            #if n1 == n2: continue
            k2=node_groups[n2]
            #if k2 not in rlist1: continue
            #if district_info[k2][1]+nodes[n1][3]-nodes[n2][3]-facilityCapacity[k2] >district_info[k2][4]: continue
            for k3 in neighbor_regions(n2):
                #if k3!=k1 and district_info[k3][1]+nodes[n2][3]>facilityCapacity[k3]: continue
                #if k3==k1 and district_info[k3][1]-nodes[n1][3]+nodes[n2][3]-facilityCapacity[k3]>district_info[k3][4]: continue
                savings=nodedik[n1][k1]+nodedik[n2][k2]
                savings-=nodedik[n1][k2]+nodedik[n2][k3]
                savings2=0
                if k3!=k1:
                    slist=[district_info[k1][1]-nodes[n1][3],district_info[k2][1]+nodes[n1][3]-nodes[n2][3],district_info[k3][1]+nodes[n2][3]]
                    savings2=district_info[k1][4]+district_info[k2][4]+district_info[k3][4]
                    savings2-=max(0,slist[0]-facilityCapacity[k1])+max(0,slist[1]-facilityCapacity[k2])+max(0,slist[2]-facilityCapacity[k3])
                if k3==k1:
                    slist=[district_info[k1][1]-nodes[n1][3]+nodes[n2][3],district_info[k2][1]+nodes[n1][3]-nodes[n2][3]]
                    savings2=district_info[k1][4]+district_info[k2][4]
                    savings2-=max(0,slist[0]-facilityCapacity[k1])+max(0,slist[1]-facilityCapacity[k2])
                #if district_info[k1][4]==0 and savings<0: continue
                if savings2<0: continue
                if savings2==0 and savings<0: continue
                #if savings<=0: continue
                count_op[1]+=1
                sp=objective_supply
                node_groups[n1] = k2
                node_groups[n2] = k3
                obj=biobjective
                #print "TUM",biobjective,objective,objective_overload,
                sp=objective_supply
                update_district_info()
                #print "->",biobjective,objective,objective_overload,":",savings,savings2,biobjective-obj
                find_best_solution += update_best_solution()
                success_move=1
                break
            if success_move==1: break            
    if spatial_contiguity>=1: repare_fragmented_solution()
    time_op[1]+=time.time()-t
    return find_best_solution

#for a region
#move out one edge unit to its neighbor region, and
#move in one edge unit from its neighbor region
def two_unit_move_geo():
    #global district_info
    global node_groups
    global time_op
    global count_op
    popa=total_pop*1.0/max_num_facility #location_problem=2,PDP
    dev=popa*pop_deviation

    t=time.time()
    find_best_solution=0
    improve = 0
    ulist=find_edge_units()
    movelist=[]

    difflist=[]
    for x in ulist:
        rlist=[r for r in NearFacilityList[x] if centersID[r]>=0]
        k=node_groups[x]
        difflist.append([x,district_info[k][4]*100000+nodedij[x][rlist[0]]-nodedij[x][k]])
    difflist.sort(key=lambda x:x[1])
    ulist_n1=[x[0] for x in difflist]
    ulist_n1=ulist[:]
    random.shuffle(ulist_n1)
    for n_id1 in ulist_n1:
        #if n_id1 in movelist: continue
        r_id1 = node_groups[n_id1]
        rlist1=neighbor_regions(n_id1)
        success_move=0
        #sol=node_groups[:]
        #sol[n_id1] = -1
        #if spatial_contiguity==1 and check_continuality_feasibility(sol,r_id1)==0:
        #    movelist.append(n_id1)
        #    continue

        for n_id2 in ulist:
            if n_id1 == n_id2: continue
            #if n_id1 in movelist: break
            #if n_id2 in movelist: continue
            if node_groups[n_id2] not in rlist1: continue
            new_r_id1=node_groups[n_id2]
            r_id2 = node_groups[n_id2]
            #sol=node_groups[:]
            #sol[n_id2] = -1
            #if spatial_contiguity==1 and check_continuality_feasibility(sol,r_id2)==0:
            #    movelist.append(n_id2)
            #    continue
            success_move=0
            for new_r_id2 in neighbor_regions(n_id2):
                obj_new = nodedik[n_id1][new_r_id1] + nodedik[n_id2][new_r_id2]
                obj_old = nodedik[n_id1][r_id1]+nodedik[n_id2][r_id2]
                new_district_info = [x[1] for x in district_info]
                new_district_info[r_id1] -= nodes[n_id1][3]
                new_district_info[r_id2] -= nodes[n_id2][3]
                new_district_info[new_r_id1] += nodes[n_id1][3]
                new_district_info[new_r_id2] += nodes[n_id2][3]
                bal=0.0
                bal=sum(new_district_info[x]-facilityCapacity[x] for x in range(num_districts) if new_district_info[x]>facilityCapacity[x])
                if location_problem==2:
                    bal=0.0
                    for x in new_district_info:
                        if x==0: continue
                        if x >popa+dev: bal+=x-popa-dev
                        if x <popa-dev: bal+=popa-dev-x
                #yfkong
                #if bal>objective_overload: continue
                if isbetter(obj_old,obj_new,objective_overload,bal)==0:
                    continue

                sol=node_groups[:]
                sol[n_id1] = new_r_id1
                sol[n_id2] = new_r_id2
                if spatial_contiguity>=1 and check_continuality_feasibility(sol,r_id1)==0:
                    #movelist.append(n_id1)
                    success_move=1
                    break
                if spatial_contiguity>=1 and check_continuality_feasibility(sol,r_id2)==0:
                    #movelist.append(n_id2)
                    break    

                count_op[1]+=1
                node_groups[n_id1] = new_r_id1
                node_groups[n_id2] = new_r_id2
                #movelist.append(n_id1)
                #movelist.append(n_id2)
                obj=objective
                #print [2,obj_old,obj_new,objective_overload,bal,biobjective],
                update_district_info()
                #print biobjective
                #if objective-obj> obj_new-obj_old+0.01:
                #     print "debug oum!!!"
                find_best_solution += update_best_solution()
                success_move=1
                break
            if success_move==1: break
    time_op[1]+=time.time()-t
    return find_best_solution
#move three units
def three_unit_move():
    global node_groups
    global time_op
    global count_op
    t=time.time()
    find_best_solution=0
    improve = 0
    ulist=find_edge_units()
    difflist=[]
    for x in ulist:
        rlist=[r for r in NearFacilityList[x] if centersID[r]>=0]
        k=node_groups[x]
        difflist.append([x,nodedik[x][rlist[0]]-nodedik[x][k]])
    difflist.sort(key=lambda x:x[1])
    ulist=[x[0] for x in difflist]
    new_r_id1 = MAXNUMBER
    new_r_id2 = MAXNUMBER
    new_r_id3 = MAXNUMBER
    r_id1 = MAXNUMBER
    r_id2 = MAXNUMBER
    r_id3 = MAXNUMBER
    #nu=len(ulist)/2
    #fulist=ulist[:nu]
    #random.shuffle(ulist)
    movelist=[]
    for n_id1 in ulist:
        if n_id1 in movelist: continue
        r_id1=node_groups[n_id1]
        improve=0
        rlist1=neighbor_regions(n_id1)
        ulist2=[x for x in ulist if node_groups[x] in rlist1] 
        random.shuffle(ulist2)
        for n_id2 in ulist2:
            if n_id1 == n_id2: continue
            if n_id1 in movelist: break
            if n_id2 in movelist: continue
            #if node_groups[n_id2] not in neighbor_regions(n_id1): continue
            new_r_id1=node_groups[n_id2]
            r_id2=node_groups[n_id2]
            rlist2=neighbor_regions(n_id2)
            ulist3=[x for x in ulist if node_groups[x] in rlist2] 
            random.shuffle(ulist3)
            for n_id3 in ulist3:
                if n_id1 == n_id3 or n_id2 == n_id3:continue
                if n_id1 in movelist: break
                if n_id2 in movelist: break
                if n_id3 in movelist: continue
                #if node_groups[n_id3] not in neighbor_regions(n_id2): continue
#                if is_edge_unit(n_id3)==False:
#                    movelist.append(n_id3)
#                    continue
                new_r_id2=node_groups[n_id3]
                r_id3=node_groups[n_id3]
                for new_r_id3 in neighbor_regions(n_id3):
                    obj_new =nodedik[n_id1][new_r_id1] + nodedik[n_id2][new_r_id2] + nodedik[n_id3][new_r_id3]
                    obj_old =nodedik[n_id1][r_id1]     + nodedik[n_id2][r_id2]     + nodedik[n_id3][r_id3]
                    new_district_info = [x[1] for x in district_info]
                    new_district_info[r_id1] -= nodes[n_id1][3]
                    new_district_info[r_id2] -= nodes[n_id2][3]
                    new_district_info[r_id3] -= nodes[n_id3][3]
                    new_district_info[new_r_id1] += nodes[n_id1][3]
                    new_district_info[new_r_id2] += nodes[n_id2][3]
                    new_district_info[new_r_id3] += nodes[n_id3][3]
                    bal=0
                    
                    bal=sum(new_district_info[x]-facilityCapacity[x] for x in range(num_districts) if new_district_info[x]>facilityCapacity[x])
                    if location_problem==2:
                        bal=0.0			
                        popa=total_pop*1.0/max_num_facility
                        dev=popa*pop_deviation
                        for x in new_district_info:
                            if x==0: continue
                            if x >popa+dev: bal+=x-popa-dev
                            if x <popa-dev: bal+=popa-dev-x
                    #yfkong
                    #if bal>objective_overload: continue
                    if isbetter(obj_old,obj_new,objective_overload,bal)==0:
                        continue
                    rlist=[r_id1,r_id2,r_id3,new_r_id1,new_r_id2,new_r_id3]
                    sol=node_groups[:]
                    sol[n_id1] = new_r_id1
                    sol[n_id2] = new_r_id2
                    sol[n_id3] = new_r_id3
                    if spatial_contiguity>=1 and check_continuality_feasibility(sol,r_id1)==0:
                        movelist.append(n_id1)
                        break
                    if spatial_contiguity>=1 and r_id1!=r_id2 and check_continuality_feasibility(sol,r_id2)==0:
                        movelist.append(n_id2)
                        break
                    if spatial_contiguity>1 and r_id1!=r_id3 and r_id2!=r_id3 and check_continuality_feasibility(sol,r_id3)==0:
                        movelist.append(n_id3)
                        break
                    count_op[2]+=1
                    node_groups[n_id1] = new_r_id1
                    node_groups[n_id2] = new_r_id2
                    node_groups[n_id3] = new_r_id3
                    #movelist.append(n_id1)
                    #movelist.append(n_id2)
                    #movelist.append(n_id3)
                    obj=biobjective
                    update_district_info()
                    improve = 1
                    find_best_solution +=  update_best_solution()
                    break
                if improve == 1:
                    break
            if improve == 1:
                break
    time_op[2]+=time.time()-t
    return find_best_solution

# three-unit moves on selected regions
def three_unit_move_simple():
    global node_groups
    global time_op
    global count_op
    t=time.time()
    find_best_solution=0
    improve = 0
    ulist=find_edge_units()
    dlist=select_region(-1)
    ulist=[x for x in ulist if node_groups[x] in dlist]
    difflist=[]
    for x in ulist:
        rlist=[r for r in NearFacilityList[x] if centersID[r]>=0]
        k=node_groups[x]
        difflist.append([x,nodedik[x][rlist[0]]-nodedik[x][k]])
    difflist.sort(key=lambda x:x[1])
    ulist=[x[0] for x in difflist]
    new_r_id1 = MAXNUMBER
    new_r_id2 = MAXNUMBER
    new_r_id3 = MAXNUMBER
    r_id1 = MAXNUMBER
    r_id2 = MAXNUMBER
    r_id3 = MAXNUMBER
    #nu=len(ulist)/2
    #fulist=ulist[:nu]
    #random.shuffle(ulist)
    movelist=[]
    for n_id1 in ulist:
        if n_id1 in movelist: continue
        r_id1=node_groups[n_id1]
        improve=0
        rlist1=neighbor_regions(n_id1)
        ulist2=[x for x in ulist if node_groups[x] in rlist1] 
        random.shuffle(ulist2)
        for n_id2 in ulist2:
            if n_id1 == n_id2: continue
            if n_id1 in movelist: break
            if n_id2 in movelist: continue
            #if node_groups[n_id2] not in neighbor_regions(n_id1): continue
            new_r_id1=node_groups[n_id2]
            r_id2=node_groups[n_id2]
            rlist2=neighbor_regions(n_id2)
            ulist3=[x for x in ulist if node_groups[x] in rlist2] 
            random.shuffle(ulist3)
            for n_id3 in ulist3:
                if n_id1 == n_id3 or n_id2 == n_id3:continue
                if n_id1 in movelist: break
                if n_id2 in movelist: break
                if n_id3 in movelist: continue
                new_r_id2=node_groups[n_id3]
                r_id3=node_groups[n_id3]
                for new_r_id3 in neighbor_regions(n_id3):
                    obj_new =nodedik[n_id1][new_r_id1] + nodedik[n_id2][new_r_id2] + nodedik[n_id3][new_r_id3]
                    obj_old =nodedik[n_id1][r_id1]     + nodedik[n_id2][r_id2]     + nodedik[n_id3][r_id3]
                    new_district_info = [x[1] for x in district_info]
                    new_district_info[r_id1] -= nodes[n_id1][3]
                    new_district_info[r_id2] -= nodes[n_id2][3]
                    new_district_info[r_id3] -= nodes[n_id3][3]
                    new_district_info[new_r_id1] += nodes[n_id1][3]
                    new_district_info[new_r_id2] += nodes[n_id2][3]
                    new_district_info[new_r_id3] += nodes[n_id3][3]
                    bal=0
                    
                    bal=sum(new_district_info[x]-facilityCapacity[x] for x in range(num_districts) if new_district_info[x]>facilityCapacity[x])
                    if location_problem==2:
                        bal=0.0
                        popa=total_pop*1.0/max_num_facility
                        dev=popa*pop_deviation
                        for x in new_district_info:
                            if x==0: continue
                            if x >popa+dev: bal+=x-popa-dev
                            if x <popa-dev: bal+=popa-dev-x
                    #yfkong
                    #if bal>objective_overload: continue
                    if isbetter(obj_old,obj_new,objective_overload,bal)==0:
                        continue
                    rlist=[r_id1,r_id2,r_id3,new_r_id1,new_r_id2,new_r_id3]
                    sol=node_groups[:]
                    sol[n_id1] = new_r_id1
                    sol[n_id2] = new_r_id2
                    sol[n_id3] = new_r_id3
                    if spatial_contiguity>=1 and check_continuality_feasibility(sol,r_id1)==0:
                        movelist.append(n_id1)
                        break
                    if spatial_contiguity>=1 and r_id1!=r_id2 and check_continuality_feasibility(sol,r_id2)==0:
                        movelist.append(n_id2)
                        break
                    if spatial_contiguity>=1 and r_id1!=r_id3 and r_id2!=r_id3 and check_continuality_feasibility(sol,r_id3)==0:
                        movelist.append(n_id3)
                        break
                    count_op[2]+=1
                    node_groups[n_id1] = new_r_id1
                    node_groups[n_id2] = new_r_id2
                    node_groups[n_id3] = new_r_id3
                    r_id1=new_r_id1
                    r_id2=new_r_id2
                    r_id3=new_r_id3

                    #movelist.append(n_id1)
                    #movelist.append(n_id2)
                    #movelist.append(n_id3)
                    obj=biobjective
                    update_district_info()
                    improve = 1
                    find_best_solution +=  update_best_solution()
                    break
                if improve == 1:
                    break
            if improve == 1:
                break
    time_op[2]+=time.time()-t
    return find_best_solution
	
# local search
def RRT_local_search():
    global improved
    #global node_neighbors
    improved=0
    #operators=[0,1,2,3,4]
    operators=assignment_operators_selected[:]
    #if op_random == 1 and random.random()>0.5:
    #    random.shuffle(operators)
    for op in operators:
        if op == 0:
            one_unit_move()
            #update_region_pool_all()
        if op == 1:
            two_unit_move()
            #update_region_pool_all()
        if op == 2:
            #if random.random()<0.1: three_unit_move()
            three_unit_move()
            #update_region_pool_all()
        if op == 3:
            three_unit_move_simple()
    return

#local search with operator op
def vnd_op_search(op):
    #global node_neighbors
    #for x in node_neighbors:
    #    random.shuffle(x)
    if op == 0:
        one_unit_move()
    if op == 1:
        two_unit_move()
    if op == 2:
        three_unit_move()
    if op == 3:
        three_unit_move_simple()
    #if 2 in assignment_operators_selected: print "VND",op, biobjective
    return

#VND search
def VND_local_search():
    global improved
    improved=0
    #operators=[0,1,2,3,4]
    operators=assignment_operators_selected[:]    
    if len(operators)==0: return
    #if op_random == 1:
    #if op_random == 1 and random.random()>0.5:
    #    random.shuffle(operators)
    obj=biobjective
    while 1:
        vnd_op_search(operators[0])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==1:break
        vnd_op_search(operators[1])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==2:break

        vnd_op_search(operators[2])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==3:break
        vnd_op_search(operators[3])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==4:break
        vnd_op_search(operators[4])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        break
    return

#VNs search
def vns_op_search(op):
    #global node_neighbors
    global node_groups
    node_groups=best_solution[:]
    update_district_info()
    obj=biobjective
    shake(op*2+2)
    #assign_ruin_recreate()
    #VND_local_search()
    vnd_op_search(op)
    #update_region_pool_all()
    return obj-biobjective

def shake(k):
    global node_groups
    if k<1: return
    ulist=find_edge_units()
    counter=0
    for uid in ulist:#(int(num_units*rate+0.5)):
        rid=node_groups[uid]
        r=neighbor_regions(uid)
        if len(r)<1: continue
        random.shuffle(r)
        node_groups[uid]=r[0]
        counter+=1
        if counter>=k: break
    if spatial_contiguity>1: repare_fragmented_solution()
    else: update_district_info()
    

def VNS_local_search():
    global improved
    improved=0
    operators=assignment_operators_selected
    count=0
    while 1:
        count+=1
        objimprove=vns_op_search(operators[0])
        if objimprove>0.00001:  continue
        if len(operators)==1:break

        count+=1
        objimprove=vns_op_search(operators[1])
        if objimprove>0.00001:  continue
        if len(operators)==2:break

        count+=1
        objimprove=vns_op_search(operators[2])
        if objimprove>0.00001: continue
        break
    return

def read_bm_instance(f1):
    global num_units
    global total_pop
    global total_supply
    global nodes
    global node_neighbors
    global nodedij
    global nodedik
    global centersID
    global facilityCandidate
    global facilityCapacity
    global facilityCost
    global num_facilityCandidate
    global num_districts
    global district_info
    global avg_dis_min
    global potential_facilities
    global geo_instance
    geo_instance=0
    node =[0,0,0,0,0,0,0,0,0,0]
    #school_nodes = []
    nodes = []
    f = open(f1)
    line = f.readline() #I,J
    line=line[0:-1]
    items = line.split(' ')
    idx=0
    for item in items:
        if item=="":
            continue
        if idx==0:
            num_districts=int(item)
            idx+=1
        else:
            num_units=int(item)
            idx+=1
    facilityCandidate=[x for x in range(num_districts)]
    facilityCapacity=[0.0 for x in range(num_districts)]
    facilityCost=[0.0 for x in range(num_districts)]
    nodes=[node[:] for x in range(num_units) ]
    nodedik=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    nodedij=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    arcpy_print("M,N: "+str(num_districts)+" "+str(num_units))
    for i in range(num_districts):
        line = f.readline()
        line=line[0:-1]
        items = line.split(' ')
        idx=0
        for item in items:
            if item=="":
                continue
            if idx==0:
                facilityCapacity[i]=float(item)
                idx+=1
            else:
                facilityCost[i]=float(item)
                idx+=1
    idx=0
    line = f.readline()
    while line: # for i in range((num_units+1)/10):
        line=line[0:-1]
        items = line.split(' ')
        for item in items:
            if item=="":
                continue
            if idx<num_units:
                nodes[idx][3]=float(item)
                idx+=1
            else:
                #i=(idx-num_units)/num_districts
                #k=(idx-num_units)%num_districts
                i=(idx-num_units)%num_units
                k=(idx-num_units)/num_units
                nodedik[i][k]=float(item)
                nodedij[i][k]=float(item)/nodes[i][3]
                idx+=1
        line = f.readline()    
    f.close()

    centersID=facilityCandidate[:]
    total_pop=sum(x[3] for x in nodes)
    total_supply=sum(facilityCapacity)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    avg_dis_min=1.0
    create_facility_neighbors()
    find_NearFacilityList(num_districts)
    find_near_customer()
    create_node_neighbors()
    #find_nearFacilityFacility()
    potential_facilities=[x for x in range(num_districts)]
    s="total demand: "+ str(total_pop)
    arcpy_print(s)
    s="total supply: "+str(total_supply)
    arcpy_print(s)

def read_bm_instance2(f1):
    global num_units
    global total_pop
    global total_supply
    global nodes
    global node_neighbors
    global nodedij
    global nodedik
    global centersID
    global facilityCandidate
    global facilityCapacity
    global facilityCost
    global num_facilityCandidate
    global num_districts
    global district_info
    global avg_dis_min
    global potential_facilities
    global geo_instance
    geo_instance=0
    node =[0,0,0,0,0,0,0,0,0,0]
    #school_nodes = []
    nodes = []
    f = open(f1)
    line = f.readline() #I,J
    line=line[0:-1]
    items = line.split(' ')
    if line.find("\t"): items = line.split('\t')
    idx=0
    for item in items:
        if item=="":
            continue
        if idx==0:
            num_units=int(item)
            idx+=1
        else:
            num_districts=int(item)
            idx+=1
    facilityCandidate=[x for x in range(num_districts)]
    facilityCapacity=[0.0 for x in range(num_districts)]
    facilityCost=[0.0 for x in range(num_districts)]
    nodes=[node[:] for x in range(num_units) ]
    nodedik=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    nodedij=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    arcpy_print("M,N: "+str(num_districts)+" "+str(num_units))

    idx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            nodes[idx][3]=float(item)
            idx+=1
        if idx==num_units: break

    fidx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            facilityCapacity[fidx]=float(item)
            fidx+=1
        if fidx==num_districts: break
    fidx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            facilityCost[fidx]=float(item)
            fidx+=1
        if fidx==num_districts: break
    idx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            k=idx/num_units
            i=idx%num_units
            idx+=1
            nodedik[i][k]=float(item)*nodes[i][3]
            nodedij[i][k]=float(item)
        if idx==num_units*num_districts: break
    f.close()
    centersID=facilityCandidate[:]
    total_pop=sum(x[3] for x in nodes)
    total_supply=sum(facilityCapacity)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    avg_dis_min=1.0
    create_facility_neighbors()
    find_NearFacilityList(num_districts)
    find_near_customer()
    #find_nearFacilityFacility()
    create_node_neighbors()
    potential_facilities=[x for x in range(num_districts)]
    s="total demand: "+ str(total_pop)
    arcpy_print(s)
    s="total supply: "+str(total_supply)
    arcpy_print(s)

def create_facility_neighbors():
    return 
    global facility_neighbors
    mindij=[[MAXNUMBER for x in range(num_districts)] for y in range(num_districts)]
    for i in range(num_districts):
        for j in range(num_districts):
            if j<=i: continue
            dlist=[nodedij[x][i]-nodedij[x][j] for x in range(num_units)]
            d=sum(x*x for x in dlist)
            mindij[i][j]=d
            mindij[j][i]=d
    facility_neighbors = [[]for x in range(num_districts)]
    for i in range(num_districts):
        dlist=[[x, mindij[i][x]] for x in range(num_districts) ]
        dlist.sort(key=lambda x:x[1])
        nghrs=[x[0] for x in dlist]
        facility_neighbors[i]=nghrs[:]


def create_node_neighbors():
    global node_neighbors
    #rlist=[x for x in range(num_districts)]
    mindij=[[MAXNUMBER for x in range(num_units)] for y in range(num_units)]
    for i in range(num_units):
        for j in range(num_units):
            if j<=i: continue
            dlist=[nodedij[i][x]-nodedij[j][x] for x in range(num_districts)]
            d=sum(x*x for x in dlist)
            mindij[i][j]=d
            mindij[j][i]=d
    node_neighbors = [[]for x in range(num_units)]
    for i in range(num_units):
        dlist=[[x, mindij[i][x]] for x in range(num_units) ]
        dlist.sort(key=lambda x:x[1])
        nn=8
        if nn>num_units: nn=num_units
        nghrs=[dlist[x][0] for x in range(nn)]
        random.shuffle(nghrs) #debug
        node_neighbors[i]=nghrs[:]

#read instance file, f1:unit info, f2: connectivity info
def readfile(f1,f2):
    global num_units
    global total_pop
    global total_supply
    global nodes
    global node_neighbors
    global nodedij
    global nodedik
    global centersID
    global facilityCandidate
    global facilityCapacity
    global facilityCost
    global num_facilityCandidate
    global num_districts
    global district_info
    global avg_dis_min
    global potential_facilities
    node =[0,0,0,0,0,0,0,0,0,0]
    #school_nodes = []
    nodes = []
    #nodes.append(node)
    ##noprint "reading nodes ...",
    f = open(f1)
    line = f.readline()  #OID    pop    PointX    PointY    fcadidature    fcost    fcapacity
    line = f.readline()
    nodeidx=0
    while line:
        line=line[0:-1]
        items = line.split(',')
        if len(items)<=2:
            items = line.split('\t')
        unit=[nodeidx, float(items[2]), float(items[3]), int(items[1]),int(items[0]),int(items[6]),int(items[4]),float(items[5])]
        nodes.append(unit)
        nodeidx+=1
        #nodes.append([int(items[1]), float(items[8]), float(items[9]), int(items[5]), int(items[6]), int(items[7]),int(items[12]),int(items[13])])
        line = f.readline()
    f.close()
    num_units=len(nodes)
    total_pop=sum(x[3] for x in nodes)
    ##noprint num_units,"units"
    ##noprint "reading connectivity ...",
    connectivity=[[0 for x in range(len(nodes))] for y in range(len(nodes))]
    ###id1,id2#####
    f = open(f2)
    line = f.readline()
    line = f.readline()
    links=0
    while line:
        items = line.split(',')
        if len(items)<=2:
            items = line.split('\t')
        if int (items[1]) != int (items[2]):
            id1=int (items[1])
            id2=int (items[2])
            idx1=-1
            idx2=-1
            for i in range(num_units):
                if nodes[i][4]==id1:
                    idx1=i
                if nodes[i][4]==id2:
                    idx2=i
                if idx1>=0 and idx2>0:
                    break
            connectivity[idx1][idx2]=1
            connectivity[idx2][idx1]=1
            links+=1
        line = f.readline()
    f.close()
    ##noprint links,"links"
    num_units=len(nodes)
    facilityCandidate=[]
    facilityCapacity=[]
    facilityCost=[]
    centersID=[]
    ##noprint "all data are read! "
    for i in range(num_units):
        if nodes[i][5]>0 or all_units_as_candadate_locations==1:
            facilityCandidate.append(i)
            facilityCapacity.append(nodes[i][5])
            facilityCost.append(nodes[i][7])
            centersID.append(i)
    num_facilityCandidate=len(facilityCandidate)
    num_districts=len(facilityCandidate)
    #facilityCandidate.sort()
    total_supply=sum(facilityCapacity)
    centersID=facilityCandidate[:]
    nodedij=[[MAXNUMBER for x in range(num_districts)] for y in range(num_units)]
    max_dij=0.0
    for i in range(num_units):
        for k in range(num_districts):
            j=facilityCandidate[k]
            d2=pow(nodes[i][1]-nodes[j][1],2)
            d2+=pow(nodes[i][2]-nodes[j][2],2)
            d=pow(d2,0.5)/1000
            nodedij[i][k]=d
            if d>max_dij:
                max_dij=d

    node_neighbors = [[]for x in range(len(nodes))]
    for i in range(len(nodes)):
        for j in range(len(nodes)):
            if j<=i:
                continue
            if connectivity[i][j]==1:
                node_neighbors[i].append(j)
                node_neighbors[j].append(i)

    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    dis=0.0
    for i in range(num_units):
        d=min(nodedij[i])
        dis+=d*nodes[i][3]
    avg_dis_min=dis/total_pop
    #weighted cost from i to k
    
    nodedik=[[nodedij[y][x]*nodes[y][3] for x in range(num_districts)] for y in range(num_units)]
    find_NearFacilityList(num_districts)
    print "find_near_customer()..."
    find_near_customer()
    #find_nearFacilityFacility()
    print "create_facility_neighbors()..."
    create_facility_neighbors()
    potential_facilities=[x for x in range(num_districts)]
    s="M N: "+str(num_districts)+" "+str(num_units)
    arcpy_print(s)

def find_nearFacilityFacility():
    global nearFacilityFacility
    nearFacilityFacility=[[] for x in range(num_districts)]
    dkk=[sum(nodedik[x][k]*nodedik[x][k] for x in range(num_units)) for k in range(num_districts)]
    #dkk.sort(key=lambda x:x[1])
    #dlist=[x[0] for x in dkk]
    for k in range(num_districts):
        d=dkk[k]
        dk=[[x,dkk[x]-d] for x in range(num_districts)]
        dk.sort(key=lambda x:x[1])
        del dk[0]
        nearFacilityFacility[k]=[x[0] for x in dk]
    
def find_near_customer():
    global nearCustomer
    global nearCustomers
    if location_problem>=2 and pmp_I_eaquls_J==1: 
        nearCustomers=NearFacilityList
        nearCustomer=[x for x in range(num_districts)]
        return
    nearCustomer=[-1 for x in range(num_districts)]
    nearCustomers=[[] for x in range(num_districts)]
    dis=[]
    for k in range(num_districts):
        dis=[ [x,nodedij[x][k]] for x in range(num_units)]
        dis.sort(key=lambda x: x[1])
        nearCustomer[k]=dis[0][0]
        nearCustomers[k]=[x[0] for x in dis]
       
def initialize_instance():
    global num_units
    global num_districts
    global num_facilityCandidate
    global centersID
    global node_groups
    global facilityCost
    global facilityCandidate
    global facilityCapacity
    global nodedik
    global avg_pop
    global total_pop
    global avg_dis_min
    global total_supply
    global fixed_cost_obj
    global max_num_facility
    global adaptive_number_of_facilities
    #solution obj 
    global district_info
    global objective_overload
    global objective
    global biobjective
    global all_solutions
    #best solution 
    global best_solution
    global best_centersID
    global best_biobjective
    global best_objective
    global best_objective_overload
    #global best solution 
    global best_solution_global
    global best_centersID_global
    global best_biobjective_global
    global best_objective_global
    global best_overload_global
    global potential_facilities
    global max_exclusion_list
    num_districts=len(facilityCandidate)
    num_units=len(nodes)
    total_pop=sum(x[3] for x in nodes)
    #print total_pop,nodes[:10]
	#sum(nodes[x][3] for x in range(num_units))
    node_groups=[-1 for x in range(num_units)]
    if location_problem==0:
        fixed_cost_obj=0
        max_num_facility=num_districts
    if fixed_cost_obj==0:
        facilityCost=[0 for x in range(num_districts)]
    if location_problem==1 and max_num_facility<=1:
        max_num_facility=num_districts
        adaptive_number_of_facilities=1
    if location_problem==2:
        if all_units_as_candadate_locations==1:
            facilityCandidate=[x for x in range(num_districts)]
            facilityCost=[0.0 for x in range(num_districts)]
            popa=total_pop*1.0/max_num_facility
            facilityCapacity=[popa for x in range(num_districts)]
        if all_units_as_candadate_locations==0:
            facilityCost=[0.0 for x in range(num_districts)]
            popa=total_pop*1.0/max_num_facility
            facilityCapacity=[popa for x in range(num_districts)]
    if location_problem==3: #pmp
        #avg_pop=total_pop/num_units
        num_districts=num_units
        facilityCandidate=[x for x in range(num_units)]
        facilityCost=[0.0 for x in range(num_units)]
        facilityCapacity=[total_pop for x in range(num_units)]
    centersID=facilityCandidate[:]
    num_facilityCandidate=len(facilityCandidate)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    total_supply=sum(facilityCapacity)
    #arcpy_print("total demand: "+str(total_pop))
    #arcpy_print("total supply: "+str(total_supply))
    #arcpy_print("avg. distance to nearest facility: "+str(avg_dis_min))

    objective_overload=MAXNUMBER
    obj_balance=MAXNUMBER
    objective=MAXNUMBER
    biobjective=MAXNUMBER
    all_solutions=[]

    #best solution in each start
    best_solution =[] # node_groups[:]
    best_centersID=[]
    best_biobjective=MAXNUMBER
    best_objective=MAXNUMBER
    best_objective_overload = MAXNUMBER

    #global best solution 
    best_solution_global=[]
    best_centersID_global=[]
    best_biobjective_global = MAXNUMBER
    best_objective_global = MAXNUMBER
    best_overload_global = MAXNUMBER
    #if geo_instance==1:
    #    nodedik=[[nodedij[y][facilityCandidate[x]]*nodes[y][3] for x in range(num_districts)] for y in range(num_units)]
    avg_dis_min =sum(nodedik[x][0] for x in range(num_units))/total_pop
    if spatial_contiguity>=1:
        find_near_customer()
    find_NearFacilityList(num_districts)
    if linear_relaxation==1:
        lplocs,sol=location_model_linear_relexation(max_num_facility,0,heuristic_time_limit,0.0001)	
        potential_facilities=[x for x in range(num_districts) if lplocs[x]>0.0001]
        print "Potential facilities by Linear Relax",potential_facilities    
    max_exclusion_list=[0.0 for x in range(num_districts)]

    
#read network distance
def readdistance(dfile):
    global nodedij
    nodedij=[[MAXNUMBER for x in range(len(nodes))] for y in range(len(nodes))]
    ##noprint "reading distances ...",
    try:
        f = open(dfile)
        line = f.readline()
        line = f.readline()
        readsuccess=1
        while line:
            items = line.split(',')
            if len(items)<=2:
                items = line.split('\t')
            if int (items[1]) != int (items[2]):
                id1=int (items[1])
                id2=int (items[2])
                idx1=-1
                idx2=-1
                for i in range(num_units):
                    if nodes[i][4]==id1:
                        idx1=i
                    if nodes[i][4]==id2:
                        idx2=i
                    if idx1>=0 and idx2>0:
                        break
                if idx1>=0 and idx2>=0:
                    nodedij[idx1][idx2]=float(items[3])
            line = f.readline()
        f.close()
        find_NearFacilityList(num_districts)
        return 1
    except:
        arcpy_print("Cannot read the distance data file!!!")
        return 0

def find_NearFacilityList(nnn):
    global NearFacilityList
    NearFacilityList=[]
    n=nnn#num_districts
    if n>num_districts: n=num_districts
    dis=0.0
    for i in range(num_units):
        if i%100==0: print ".",
        fdlist=[ [x,nodedik[i][x]] for x in range(num_districts)]
        fdlist.sort(key=lambda x:x[1])
        flist=[x[0] for x in fdlist[0:n]]
        NearFacilityList.append(flist)
    if geo_instance==0:
        return
            

def SSCFLP_SSCKFLP_model(numf,r,maxtime,mipgap):  #SSCFLP, SSCKFLP
    global node_groups
    global centersID
    global num_districts
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            if r==0:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            if r==1:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(random.random()+49.5)/50
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        if r==0:
            costs["y_" +str(i)]=facilityCost[i]
        if r==1:
            costs["y_" +str(i)]=facilityCost[i]*(random.random()+49.5)/50
    hvariables={}
    for i in range(num_districts):
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj

    #con2 1
    s=""
    s2=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
        s2+=facilityCapacity[k]*yvariables["y_" +str(k)]
    if adaptive_number_of_facilities==0:
        prob +=s == numf
    #else:
    #    prob +=s == numf

    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    for k in range(num_districts):
        s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
        prob+=s <= 0
    #cons 5 #can be removed
    for i in range(num_units):
        for k in range(num_districts):
            s=xvariables["x_" +str(i) + "_"+ str(k) ]- 100000*yvariables["y_" +str(k)]
            prob+=s <= 0

    not_opt_cands=[]
    for k in range(num_districts): 
        #print max_exclusion_list[k],biobjective,max_exclusion_list[k]>biobjective+0.0000001
        if max_exclusion_list[k] > biobjective+0.0000001:
            not_opt_cands.append(k)
    for k in not_opt_cands:
        s=yvariables["y_" +str(k)]
        prob+= s==0
    must_opt_cands=[]
    for k in range(num_districts): 
        if max_inclusion_list[k] >biobjective+0.0000001:
            must_opt_cands.append(k)
    for k in must_opt_cands:
        s=yvariables["y_" +str(k)]
        prob+= s==1
    #print biobjective
    s="not_in_opt_cands: "+str(len(not_opt_cands)) + " : " +str(not_opt_cands)
    arcpy_print(s)
    #print "excl",max_exclusion_list
    s1="must_in_opt_cands: "+str(len(must_opt_cands)) + " : " +str(must_opt_cands)
    arcpy_print(s1)
    #print "excl",max_inclusion_list

    #prob.writeLP("_location.lp")
    initvalues=cflp_mst()
    for x,v in initvalues: 
        if x.find("x")==0:  xvariables[x].setInitialValue(v)
        if x.find("y")==0:  yvariables[x].setInitialValue(v)
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=mipgap
    solver=""
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(mip=1,msg=solver_message,timeLimit=maxtime,gapRel = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(mip=1,msg=solver_message,timeLimit=maxtime, warmStart=True,options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(mip=1,msg=solver_message,timeLimit=maxtime,warmStart=True,options=[("MIPGap",gap),("TimeLimit",maxtime)])
    solver.setTmpDir()
    solver.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return prob.status
    sol=[]
    cid=[]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                cid.append(i)
                continue
            if items[0]=='h': continue
            k=int(items[2])
            node_groups[i]=k

    ###noprint sol
    #num_districts=len(centersID)
    centersID=facilityCandidate[:]
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    #s="not_opt_cands: "+str(len(not_opt_cands)) + " : " +str(not_opt_cands)
    arcpy_print(s)
    arcpy_print(s1)
    return prob.status

def cflp_mst():
    vars=[]
    for i in range(num_units):
        k=node_groups[i]
        if k<0: continue
        v='x_'+str(i)+ '_'+ str(k)
        vars.append([v,1])
    for i in range(num_districts):
        if centersID[i]<0:continue
        v='y_'+str(i)
        vars.append([v,1])
    return vars
def location_model_linear_relexation(numf,r,maxtime,mipgap):
    global node_groups
    global centersID
    global num_districts
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpContinuous)
            if r==0:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            if r==1:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(random.random()+19.5)/20
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpContinuous)
        costs["y_" +str(i)]=facilityCost[i]

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    prob += obj

##    for k in facilityCandidate:
##        if nodes[k][6]!=1:
##            continue
##        s=xvariables["x_" +str(k)+ "_"+ str(k)]
##        prob +=s == 1
    
##    for k in facilityCandidate:
##        if nodes[k][6]==1:
##            s=yvariables["y_" +str(k)]
##            prob +=s == 1

    #con2 1
    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if adaptive_number_of_facilities==0:
        prob +=s == numf
    #else:
    #    prob +=s == numf
    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        #s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    #for k in range(num_districts):
    #    s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
    #    prob+=s <= 0
    #cons 5 #can be removed
    for i in range(num_units):
        for k in range(num_districts):
            s=nodes[i][3]*xvariables["x_" +str(i) + "_"+ str(k) ]- facilityCapacity[k]*yvariables["y_" +str(k)]
            prob+=s <= 0

    #prob.writeLP("_location.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=mipgap
    solver=""
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(msg=solver_message,timeLimit=maxtime,gapRel = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(msg=solver_message,timeLimit=maxtime)
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(msg=solver_message,options=[("MIPGap",gap),("TimeLimit",maxtime)])
    solver.setTmpDir()
    solver.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return prob.status
    sol=[ [x,0.0,[]] for x in range(num_districts)]
    yk=[0.0 for x in range(num_districts)]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue > 0.0):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                sol[i][1]=v.varValue
                yk[i]=v.varValue
                continue
            if items[0]=='h': continue
            k=int(items[2])
            sol[k][1]+=nodes[i][3]*v.varValue
            sol[k][2].append([i,nodedik[i][k]*v.varValue])
    return yk,sol

def get_cand_locations(dlist,ulist):
    clist=[[x,max_exclusion_list[x]] for x in range(num_districts) if centersID[x]<0 and nearCustomer[x] in ulist and x in potential_facilities]
    clist.sort(key=lambda x:x[1])
    clist=[x[0] for x in clist]
    nc=len(clist)
    nf=len(dlist)
    nu=len(ulist)
    t=time.time()
    mnsize=min(3000,num_units*num_districts/10)
    ns=min(nc,mnsize/nu-nf)
    #ns=nc
    if ns<nf: ns=min(nc,nf)
    if ns==nc: return [clist]
    #cloclist=clist[:ns/2]
    #while len(cloclist)<ns:
    #    r=random.random()
    #    idx=int(r**1.5*0.999*(nc-ns/2))
    #    k=clist[ns/2+idx]
    #    if k not in cloclist: cloclist.append(k)
    #cloclist.append(clist[:ns])
    cloclist=[]
    clist1=clist[:ns/2]
    clist2=clist[ns/2:]
    for i in range(5):
        if initial_solution_method!=9:
            random.shuffle(clist)
            cloclist.append(clist[:ns])
        else:
            random.shuffle(clist2)
            cloclist.append(clist1+clist2[:ns/2])
    #print nf,nu,mnsize,nc+nf,ns+nf,
    return cloclist

location_sub_model_tabu_list=[]
def location_sub_model(dlist,ulist,mipgap): # SSCFLP,SSCKFLP for subproblem
    global location_sub_model_tabu_list
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("sub_location",pulp.LpMinimize)
    cloclist=get_cand_locations(dlist,ulist)
    centers=[]
    for clist in cloclist:
        tblist=list(set(clist+dlist))
        tblist.sort()
        #print "@",
        if tblist+centersID not in location_sub_model_tabu_list:
            centers=tblist
            break
        #print "+",
    if len(centers)==0: return []
    location_sub_model_tabu_list.append(centers[:]+centersID[:])

    exist_facility=[x for x in range(num_districts) if centersID[x]>=0 and x not in dlist and facilityCapacity[x] > district_info[x][1]]
    #if location_problem==2: exist_facility=[]
    #print dlist,centers,exist_facility
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in ulist:
        for j in centers:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
        for j in exist_facility:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
    yvariables={}
    for i in centers:
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        costs["y_" +str(i)]=facilityCost[i]
    
    hvariables={}
    for i in centers:
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)
        for i in exist_facility:
            hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)
    if location_problem==2:
        for i in centers:
            hvariables["l_" +str(i)]=pulp.LpVariable("l_" +str(i), 0, None, pulp.LpInteger)
        for i in exist_facility:
            hvariables["l_" +str(i)]=pulp.LpVariable("l_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj


    #con 1
    if adaptive_number_of_facilities==0 or location_problem==2:
        s=""
        for k in centers:
            s+=yvariables["y_" +str(k)]
        prob +=s == len(dlist)

    #cons 2
    for i in ulist:
        s=""
        for j in centers:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        for j in exist_facility:
            v="x_" +str(i)+ "_"+ str(j)
            if v in xvariables : s+=xvariables[v]
        prob +=s == 1
    #cons 3
    for k in centers:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]

        s1=s-hvariables["h_" +str(k)]
        s1-=facilityCapacity[k]*(1+pop_deviation) * yvariables["y_" +str(k)]
        prob+=s1 <= 0
        if location_problem==2:
            s2=s+hvariables["l_" +str(k)]
            s2-=facilityCapacity[k]*(1-pop_deviation) * yvariables["y_" +str(k)]
            prob+=s2 >= 0
            
    for k in exist_facility:
        s=""
        for i in ulist:
            v="x_" +str(i)+ "_"+ str(k)
            if v in xvariables: s+=nodes[i][3]*xvariables[v]
        #s-=facilityCapacity[k]
        prob+= s-hvariables["h_" +str(k)] <= facilityCapacity[k]*(1+pop_deviation) - district_info[k][1]
        if location_problem==2:
            prob+= s+hvariables["l_" +str(k)] >= facilityCapacity[k]*(1-pop_deviation) - district_info[k][1]

    #cons 4
    for k in centers:
        s=hvariables["h_" +str(k)]-total_pop*yvariables["y_" +str(k)]
        prob+=s <= 0

    #cons 5 #can be removed
    #for i in ulist:
    #    for k in centers:
    #        s=xvariables["x_" +str(i) + "_"+ str(k) ]- 100000*yvariables["y_" +str(k)]
    #        prob+=s <= 0
    # assign facility unit to itself

    if geo_instance==1 and spatial_contiguity>=1:
        for k in centers:
            u=facilityCandidate[k]
            s=xvariables["x_" +str(u) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s == 0

    #prob.writeLP("_sub_location.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    initvalues=loc_sub_mst(dlist,ulist)
    for x,v in initvalues:
        if x.find("x")==0:  xvariables[x].setInitialValue(v)
        if x.find("y")==0:  yvariables[x].setInitialValue(v)
    gap=mipgap
    if spatial_contiguity>=1: gap=0.005
    timelmt=5
    #solver_message
    solver=""
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(mip=1,msg=0,gapRel = gap*5,warmStart=True,options=['vnd on','seconds 10', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(mip=1,msg=0, warmStart=True,timeLimit=5, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(mip=1,msg=0,warmStart=True, options=[("MIPGap",gap),("TimeLimit",5)] )
    solver.setTmpDir()
    solver.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return []
    solx=[0.0 for x in range(num_units)]
    sol=[-1 for x in range(num_units)]
    nlist=[]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                nlist.append(i)
                continue
            if items[0]=='h': continue
            if items[0]=='l': continue
            x=v.varValue*100
            if x>solx[i]:
                solx[i]=x
                k=int(items[2])
            sol[i]=k
    nc=sum( 1 for x in range(num_districts) if centersID[x]<0 and nearCustomer[x] in ulist and x in potential_facilities)
    #print len(dlist),len(ulist),len(centers),nc+len(dlist),
    # clist=list(set(sol))
    # if -1 in clist: clist.remove(-1)
    # clist = [x for x in clist if x not in centersID]
    # if len(clist)!=len(dlist):
        # prob.writeLP("_sub_location.lp")
        # print dlist,clist,centers
        # print exist_facility
        # print list(set(sol))
        # for v in prob.variables():
            # if v.varValue >= 0.90:
                # if v.name.find("x")>0: continue
                # print v.name, v.varValue
        # exit()
        #prob.writeLP("_sub_location.lp")
    #print [x for x in dlist if x not in nlist],[x for x in nlist if x not in dlist],[x for x in range(num_districts) if x in sol and x not in nlist],
    return sol
def loc_sub_mst(dlist,ulist):
    vars=[]
    for i in ulist:
        k=node_groups[i]
        if k<0: continue
        v='x_'+str(i)+ '_'+ str(k)
        vars.append([v,1])
    for i in dlist:
        if centersID[i]<0:continue
        v='y_'+str(i)
        vars.append([v,1])
    return vars


def assign_sub_model(dlist): #SAP for subproblem
    global node_groups
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    alpha_coeff=avg_dis_min*pop_dis_coeff
    #if spatial_contiguity==1:alpha_coeff=avg_dis_min*10
    prob = pulp.LpProblem("sub_assign",pulp.LpMinimize)
    centers=dlist
    xvariables={}
    costs={}
    exist_facility=[x for x in range(num_districts) if centersID[x]>=0 and x not in dlist and facilityCapacity[x]-district_info[x][1]>0]
    #print dlist,nlist,ulist
    for i in ulist:
        for j in centers:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            #if spatial_contiguity==1: costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*nodedij[i][j]*(149.5+random.random())/150
        for j in exist_facility:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            #if spatial_contiguity==1: costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*nodedij[i][j]*(149.5+random.random())/150
    hvariables={}
    for i in centers:
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj

    #cons 2
    for i in ulist:
        s=""
        for j in centers:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        for j in exist_facility:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in centers:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        prob+=s <= facilityCapacity[k]
    for k in exist_facility:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        prob+=s <= facilityCapacity[k]-district_info[k][1]

    # assign facility unit to itself
    #prob.writeLP("_assign.lp")
    initvalues=assign_sub_mst(dlist,ulist)
    for x,v in initvalues:
        xvariables[x].setInitialValue(v)
    gap=0.001
    solver=""
    #solver_message
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(mip=1,msg=0,gapRel = gap,warmStart=True,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(mip=1,msg=0, warmStart=True,options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(mip=1,msg=0,warmStart=True,options=[("MIPGap",gap),("TimeLimit",5)])
    solver.setTmpDir()
    solver.actualSolve(prob)
    #sol=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            if items[0]=='h': 
                continue
            i=int(items[1])
            k=int(items[2])
            node_groups[i]=k
            #sol[i]=k
    update_district_info()
    #return prob.objective.value()
def tp_sub_model(dlist): #SAP for subproblem
    global node_groups
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("sub_assign",pulp.LpMinimize)
    centers=dlist
    xvariables={}
    costs={}
    exist_facility=[x for x in range(num_districts) if centersID[x]>=0 and x not in dlist and facilityCapacity[x]-district_info[x][1]>0]
    #print dlist,nlist,ulist
    for i in ulist:
        for j in centers:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpContinuous)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(49.5+random.random())/50
        for j in exist_facility:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpContinuous)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(49.5+random.random())/50

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    prob += obj

    #cons 2
    for i in ulist:
        s=""
        for j in centers:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        for j in exist_facility:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in centers:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        prob+=s <= facilityCapacity[k]
    for k in exist_facility:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        prob+=s <= facilityCapacity[k]-district_info[k][1]
    # assign facility unit to itself
    #prob.writeLP("_assign.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    #assign_sub_mst("_assgnsub.mst",dlist,ulist)
    gap=0.0005
    solver=""
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(msg=0,gapRel = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(msg=0)
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(msg=0,options=[("MIPGap",gap)])
    solver.setTmpDir()
    solver.actualSolve(prob)
    sol=[0.0 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.01):
            items=v.name.split('_')
            i=int(items[1])
            k=int(items[2])
            if v.varValue>sol[i]:
                node_groups[i]=k
                sol[i]=v.varValue
    update_district_info()
    #return prob.objective.value()

def assign_sub_mst(dlist,ulist):
    vars=[]
    for i in ulist:
        k=node_groups[i]
        if k<0: continue
        v='x_'+str(i)+ '_'+ str(k)
        vars.append([v,1])
    return vars
def assign_tp_sub_model(dlist): #SAP for subproblem
    global node_groups
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("sub_assign",pulp.LpMinimize)
    centers=dlist
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    exist_facility=[x for x in range(num_districts) if centersID[x]>=0 and x not in dlist]
    #print dlist,nlist,ulist
    for i in ulist:
        for j in centers:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, None, pulp.LpInteger)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedij[i][j]
        for j in exist_facility:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, None, pulp.LpInteger)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedij[i][j]

    hvariables={}
    for i in centers:
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj

    #cons 2
    for i in ulist:
        s=""
        for j in centers:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        for j in exist_facility:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == nodes[i][3]
    #cons 3
    for k in centers:
        s=""
        for i in ulist:
            s+=xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        prob+=s <= facilityCapacity[k]
    for k in exist_facility:
        s=""
        for i in ulist:
            s+=xvariables["x_" +str(i)+ "_"+ str(k)]
        prob+=s <= facilityCapacity[k]-district_info[k][1]

    # assign facility unit to itself
    #prob.writeLP("_assign.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=0.0000001
    solver=""
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(mip=1,msg=solver_message,gapRel = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(mip=1,msg=solver_message, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(mip=1,msg=solver_message,options=[("MIPGap",gap)])
    solver.setTmpDir()
    solver.actualSolve(prob)
    sol=[0 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            xik=v.varValue
            items=v.name.split('_')
            if items[0]=='h': 
                continue
            i=int(items[1])
            k=int(items[2])
            if xik>sol[i]:
                sol[i]=xik
                node_groups[i]=k
            #sol[i]=k
    update_district_info()
    print objective_overload,
    #return prob.objective.value()

# search upper bound with LR results
def upper_bound_CFLP(yobj,ylist,xijlist,gi):
    global node_groups
    global centersID
    global district_info
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_districts)]
    supply=0
    total_fcost=[facilityCapacity[x] for x in range(num_districts) if yobj[x]<0]
    total_tcost=0.0
    for k in range(num_districts):
        if yobj[x]>=0: continue
        total_tcost += sum(xijlist[k][x]* nodedik[x][k] for x in range(num_units))

    for k in range(num_districts):
        district_info[k][1]=0
        district_info[k][3]=0
        if yobj[k]<0:
            centersID[k]=facilityCandidate[k]
            district_info[k][3]=facilityCapacity[k]
            supply+=facilityCapacity[k]
            #if supply>=total_pop and total_fcost>total_tcost: break
    if supply<total_pop:
        faclist=[[k,yobj[k]] for k in range(num_districts) if yobj[k]>=0]
        faclist.sort(key=lambda x: x[1])
        while 1:
            r=random.random()
            idx=int((r*r*0.9999*len(faclist)))
            k=faclist[idx][0]
            if centersID[k]>=0: continue
            centersID[k]=facilityCandidate[k]
            district_info[k][3]=facilityCapacity[k]
            supply+=facilityCapacity[k]
            if supply>=total_pop: break
    #delete overlap location
    supply=sum(facilityCapacity[x] for x in range(num_districts) if centersID[x]>=0)
    if adaptive_number_of_facilities==1:
        for i in range(num_districts):
            if centersID[i]<0: continue
            ilist=[ x for x in range(num_units) if xij[i][x]==1]
            for j in range(num_districts):
                if centersID[j]<0: continue
                if i==j: continue
                jlist=[ x for x in range(num_units) if xij[j][x]>=0.0001]
                cover=1
                for u in jlist:
                    if u not in ilist:
                        cover=0
                        break
                if cover==1: 
                    #print "overlayed",i,j
                    centersID[j]=-1
                    district_info[j][3]=0
                    supply-=facilityCapacity[j]
                    break
    if spatial_contiguity>=1:
        for k in range(num_districts):
            if centersID[k]>=0:
                i=nearCustomer[k]
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
    for i in range(num_units):
        if node_groups[i]>=0: continue
        #klist=[[x,nodedik[i][x]/xijlist[x][i]] for x in range(num_districts) if xijlist[x][i] > 0.99 and centersID[x]>=0 and yobj[x]<0] #0.66
        klist=[[x,nodedik[i][x]] for x in range(num_districts) if xijlist[x][i] > 0.999 and centersID[x]>=0 and yobj[x]<0] #0.66
        if len(klist)==0: continue
        klist.sort(key=lambda x:x[1])
        k=klist[0][0]
        node_groups[i]=k
        district_info[k][1]+=nodes[i][3]

    #assign large unit at first, this tends to a feasible solution
    ulist=[ [x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
    ulist.sort(key=lambda x: -x[1])
    ulist=[x[0] for x in ulist]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[i]=k
                break
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    pop=sum(nodes[x][3] for x in ulist)
    if adaptive_number_of_facilities==1 and supply<total_pop:
        best_new_facility=-1
        best_new_cost=MAXNUMBER
        for k in range(num_districts):
            if centersID[k]>=0:continue
            if facilityCapacity[k]<pop: continue
            if supply+facilityCapacity[k]<total_pop: continue
            new_cost=facilityCost[k]
            new_cost+=sum(nodedik[x][k] for x in ulist)
            if new_cost<best_new_cost:
                best_new_cost=new_cost
                best_new_facility=k
        if best_new_facility!=-1:
            centersID[best_new_facility]=facilityCandidate[best_new_facility]
            district_info[best_new_facility][3]=facilityCapacity[best_new_facility]
            for x in ulist: node_groups[x]=best_new_facility
    #assign the remaining units
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            district_info[k][1]+=nodes[i][3]
            break
    #print len(ulist), sum(nodes[x][3] for x in ulist)
    delete_empty_facility()
    update_district_info()
    update_best_solution()
    #repare_fragmented_solution()
    VND_local_search()
    delete_empty_facility()
    update_district_info()
    update_district_info()
    update_best_solution()
    #print biobjective,
    return biobjective

def LR_main(loops):
    if location_problem==0: return AP_LR_main(loops,0.0001,0.0001)
    if location_problem==1: 
        if adaptive_number_of_facilities==1: 
            #location_construction_random()
            return CFLP_LR_main(loops)
        if adaptive_number_of_facilities==0: return CKFLP_LR_main(loops)
    if location_problem==2: return CKFLP_LR_main(loops)
    #if location_problem==3: return CKFLP_LR_main(loops)
multiplier=[]
yj=[]
xij=[]
subobj=[]
max_exclusion_list=[]
max_inclusion_list=[]
exclusion=[]
inclusion=[]

#LR for classical CFLP
def CFLP_LR_main(loops):
    global node_groups
    global centersID
    global multiplier
    global exclusion
    global inclusion
    global max_exclusion_list
    global max_inclusion_list
    global yj
    global xij
    global subobj
    global all_solutions
    global spatial_contiguity
    global potential_facilities
    max_exclusion_list=[0.0 for k in range(num_districts)]
    max_inclusion_list=[0.0 for k in range(num_districts)]
    #spatial_contiguity_tmp=spatial_contiguity
    #spatial_contiguity=0
    flist=[]
    xijlist=[]
    nf=num_districts/2-int(num_districts*total_pop/sum(facilityCapacity))/2
    #maxr=sum(sum(x) for x in nodedij)/num_districts/num_units
    #r=maxr/math.sqrt(nf*1.0)
    #multiplier=[r*nodes[x][3]*(49.5+random.random())/50 for x in range(num_units)]
    multiplier=[0.0 for x in range(num_units)]
    unitcost=sum(facilityCost)*1.0/sum(facilityCapacity)
    for i in range(num_units):
        k=NearFacilityList[i][1]
        ui=nodedik[i][k]+nodes[i][3]*unitcost
        multiplier[i]=ui*(49.5+random.random())/50
    # avgdis=objective/total_pop
    # avgcost=sum(facilityCost)*1.0/sum(facilityCapacity)
    # for i in range(num_units):
        # #k=node_groups[i]
        # #c=facilityCost[k]*1.0/facilityCapacity[k]
        # #ui=nodedik[i][k]+c*nodes[i][3]
        # ui=nodes[i][3]*(avgdis+avgcost)
        # multiplier[i]=ui
    subobj=[0.0 for x in range(num_districts)]
    xij=[[] for x in range(num_districts)]
    yj=[0 for x in range(num_districts)]
    gi=[1.0 for  x in range(num_units)]
    gi_possibility=gi[:]
    ub=sum(facilityCost)*total_pop/sum(facilityCapacity)+sum(multiplier)
    ub=sum(facilityCost)+sum(nodedik[x][NearFacilityList[x][-1]] for x in range(num_units))+sum(multiplier)
    unf=num_districts
    fub=ub
    unf=sum(1 for x in centersID if x>=0)
    lb=-MAXNUMBER
    delta1=0.001
    delta2=0.01
    alpha=1.0
    old_multiplier=multiplier[:]
    best_yj=yj[:]
    best_xij=copy.deepcopy(xij)
    best_multiplier=multiplier[:]
    improved_lb=1
    improved_ub=1
    best_lb_list=[]
    exclusion=[x for x in range(num_districts) if x not in potential_facilities]
    inclusion=[]
    for loop in range(loops):
        old_multiplier=multiplier[:]
        old_gi=gi[:]
        rlist=[]
        for k in range(num_districts):
            if k in exclusion:
                subobj[k]=MAXNUMBER
                xij[k]=[0.0 for x in range(num_units)]
                yj[k]=0
                continue
            obj,y,xi=sub_CFLP_LR(k)
            subobj[k]=obj
            xij[k]=xi[:]
            yj[k]=y

        flb=sum(x for x in subobj if x<0)+sum(multiplier)#[x] for x in range(num_units) if gi[x]<=0)
        #Facility exclusion, Holmberg,1999
        for k in range(num_districts):
            if subobj[k]<MAXNUMBER and flb+subobj[k]>max_exclusion_list[k]: 
                max_exclusion_list[k]=flb+subobj[k] #??? instance p43
            if subobj[k]<MAXNUMBER and flb+subobj[k]>ub:
                if k not in exclusion: exclusion.append(k)
            if subobj[k]<0 and flb-subobj[k]>ub:
                if k not in inclusion: inclusion.append(k)
            if subobj[k]<0 and flb-subobj[k]>max_inclusion_list[k]: 
                max_inclusion_list[k]=flb - subobj[k] #???
        #supply > demand
        num=sum(1 for x in subobj if x<0)
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<0)
        for i in range(num_units):
            g=1.0
            for k in range(num_districts):
                if subobj[k]>0: continue
                g-=xij[k][i]
            gi[i]=g
        norm=sum(gi[x]*gi[x] for x in range(num_units))/num_units
        #flb-=sum(gi[x]*avg_dis_min*nodes[x][3] for x in range(num_units) if gi[x]>0)
        #print norm, total_supply, total_pop,
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)
        if total_supply>=total_pop:
            best_lb_list.append([subobj[:],yj[:],copy.deepcopy(xij)])
            best_lb_list.sort(key=lambda x: x[0])
            if len(best_lb_list)>10: del best_lb_list[-1]

        improved_lb+=1
        #print lb,flb,
        if flb>lb+0.000001:# and total_supply>=total_pop:
            lb=flb
            improved_lb=0
            d=sum(old_gi[x]*gi[x] for x in range(num_units))
            if d>=0.0:
                alpha*=1.1
                if alpha>2: alpha=2.0
        if improved_lb%10==9:
            alpha*=0.66
        cap=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)

        if (loop==20 or improved_lb==0) and loop>=20:
            #if cap>-1000000:#cap>=total_pop:
                obj=upper_bound_CFLP(subobj,yj,xij,gi)
                if obj>0.000001:
                    all_solutions.append([biobjective,centersID[:],node_groups[:],objective,objective_fcost,objective_overload,max(0,total_pop-objective_supply)])
                    #update_region_pool_all()
        
        fub=biobjective
        nf=sum(1 for x in range(num_districts) if subobj[x]<=0)
        if fub>0 and fub<ub:
            ub=fub
            unf=sum(1 for x in range(num_districts) if centersID[x]>=0)
        #update multiplier	
        sq=sum(x*x for x in gi)
        if abs(sq)<0.001:
            #for k in range(num_districts):
            #    if flb+subobj[k]>max_exclusion_list[k]: max_exclusion_list[k]=flb+subobj[k] #??? instance p43
            if len(all_solutions)<=0:
                obj=upper_bound_CFLP(subobj,yj,xij,gi)
                if obj>0.00001:
                    all_solutions.append([biobjective,centersID[:],node_groups[:],objective,objective_fcost,objective_overload,max(0,total_pop-objective_supply)])
                    #update_region_pool_all()
            break
        #print gi
        t=alpha*(ub-flb)/sq
        for i in range(num_units):
            multiplier[i]+=t*gi[i]
            #if cap<total_pop: multiplier[i]*=1.01
            if multiplier[i]<0.0:
                multiplier[i]=0.0
                if gi[0]>0.999: 
                    n=nf/3
                    if n==0: continue
                    s=0.0
                    klist=[x for x in NearFacilityList[i] if subobj[x]<=0]
                    r=sum(nodedik[i][x] for x in klist[:n])/n
                    multiplier[i]=r
        cap=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)
        cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)

        viol=sum(1 for x in gi if abs(x)>0.5)
        viol1=sum(1 for x in gi if x>0.5)
        viol2=sum(1 for x in gi if x<-0.5)

        s=str(loop)+" bestub: "+str(unf)+" "+str(int(ub)) + " ub: "+str(int(fub))
        s+=" bestlb: " +str(int(lb)) + " lb: " +str(nf) +" " +str(int(flb)) 
        #s+=" bestlb: " +str(int(lb)) + " lb: " +str(nf)+" "+str(viol)+" "+str(viol1)+" "+str(viol2)+" " + str(int(norm*100))+" "
        #s+=str(int(flb)) +" "+ str(cap)+" " +str(int(alpha*100000)/100000.0) +" "+str(len(exclusion))
        #s+=" "+str(len(inclusion))
        arcpy_print(s)
        #if improved_lb>=100: 
        #    break
        if ub<lb:
            print "debug: LR, ub<lb!!",ub,lb
            print sum(x for x in subobj if x<=0)+sum(multiplier)
            print subobj
            print multiplier
        #if ub>0 and(ub-lb)/ub<0.0005:
        #    break
        if norm<0.01: break
    #print all_solutions
    all_solutions.sort(key=lambda x:x[0])
    #all_solutions.sort(key=lambda x:x[3]+x[4]+x[5]*2*avg_dis_min+x[6]*pop_dis_coeff*avg_dis_min)
    all_solutions=pop_selection(all_solutions)
    #while len(all_solutions)>max(multi_start_count*2,5): all_solutions.pop()
    while len(all_solutions)>multi_start_count: all_solutions.pop()
    #spatial_contiguity=spatial_contiguity_tmp
    #potential_facilities=[x for x in range(num_districts) if x not in exclusion]
    potential_facilities=[x for x in range(num_districts)]

def sub_CFLP_LR(idx):
    udlist=[[i,(nodedik[i][idx]-multiplier[i])/nodes[i][3]] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    #udlist=[[i,(nodedik[i][idx]-multiplier[i])] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    udlist.sort(key=lambda x: x[1])
    demand=0
    xlist=[0.0 for i in range(num_units)]
    f=0.0
    if location_problem==1:
        f=facilityCost[idx]
    for i in range(len(udlist)):
        u=udlist[i][0]
        if demand+nodes[u][3]<=facilityCapacity[idx]:
            demand+=nodes[u][3]
            f+=nodedik[u][idx]-multiplier[u]
            xlist[u]=1.0
        else:
            r=(facilityCapacity[idx]-demand)*1.0/nodes[u][3]
            f+=r*(nodedik[u][idx]-multiplier[u])
            xlist[u]=r
            break
    #if f>=0.0:
    #    return 0.0,0,[0.0 for i in range(num_units)]
    return f,1,xlist

# search upper bound with best LR solutions 
def upper_bound_CKFLP(ylist,xijlist):
    global node_groups
    global centersID
    global all_solutions
    global district_info
    if sum(ylist)<1: return MAXNUMBER
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_districts)]
    for k in range(num_districts):
        district_info[k][1]=0
        district_info[k][3]=0
        if ylist[k]==1:
            centersID[k]=facilityCandidate[k]
            district_info[k][3]=facilityCapacity[k]
    #assign demand units with integer xij in LR solution
    #assign near unit to facility
    fulist=[]    
    if spatial_contiguity ==1:
        for k in range(num_districts):
            if ylist[k]==1:
                i=nearCustomer[k]
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
                fulist.append(i)
    for i in range(num_units):
        if i in fulist: continue
        klist=[[x,nodedik[i][x] ] for x in range(num_districts) if xijlist[x][i] > 0.99] #0.66
        if len(klist)==0: continue
        klist.sort(key=lambda x: x[1])
        for x in klist:
            k=x[0]
            if centersID[k]<0: continue
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
                break
    #assign large unit at first
    ulist=[ [x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
    ulist.sort(key=lambda x: -x[1])
    ulist=[x[0] for x in ulist]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[i]=k
                break
    #assign demand units
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            district_info[k][1]+=nodes[i][3]
            break
    if adaptive_number_of_facilities==1: delete_empty_facility()
    update_district_info()
    if location_problem==2 and all_units_as_candadate_locations==1: update_centers()
    if location_problem==1 and all_units_as_candadate_locations==1: update_centers()

    VND_local_search()
    #delete_empty_facility()
    cost=objective
    cost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    supply=sum(facilityCapacity[x] for x in range(num_districts) if centersID[x]>=0)
    return biobjective
#LR for CKFLP
def CKFLP_LR_main(loops):
    global node_groups
    global centersID
    global multiplier
    global yj
    global xij
    global subobj
    global all_solutions
    global spatial_contiguity
    global max_exclusion_list
    global max_inclusion_list
    max_exclusion_list=[0.0 for k in range(num_districts)]
    max_inclusion_list=[0.0 for k in range(num_districts)]
    #spatial_contiguity_tmp=spatial_contiguity
    #spatial_contiguity=0
    flist=[]
    xijlist=[]
    nf=max_num_facility
    multiplier=[0.0 for x in range(num_units)]
    unitcost=sum(facilityCost)*1.0/sum(facilityCapacity)
    for i in range(num_units):
        k=NearFacilityList[i][1]
        ui=nodedik[i][k]+nodes[i][3]*unitcost
        multiplier[i]=ui*(49.5+random.random())/50
    subobj=[0.0 for x in range(num_districts)]
    xij=[[] for x in range(num_districts)]
    yj=[0 for x in range(num_districts)]
    gi=[1.0 for  x in range(num_units)]
    gi_possibility=gi[:]
    #ub=sum(facilityCost)+sum(multiplier)
    ub=sum(facilityCost)*total_pop/sum(facilityCapacity)+sum(multiplier)
    fub=ub
    unf=sum(1 for x in centersID if x>=0)
    #all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
    lb=-MAXNUMBER
    delta1=0.001
    delta2=0.01
    alpha=1.0
    old_multiplier=multiplier[:]
    best_yj=yj[:]
    best_xij=copy.deepcopy(xij)
    best_multiplier=multiplier[:]
    improved_lb=0
    improved_ub=0
    last_ji=[]
    best_lb_list=[]
    exclusion=[]
    for loop in range(loops):
        #search lower bound
        old_multiplier=multiplier[:]
        old_gi=gi[:]
        rlist=[]
        for k in range(num_districts):
            if k in exclusion:
                subobj[k]=0.0
                xij[k]=[0.0 for x in range(num_units)]
                yj[k]=0
            obj,y,xi=sub_CKFLP_LR(k)
            subobj[k]=obj
            xij[k]=xi[:]
            yj[k]=y

        flb=sum(x for x in subobj if x<0)+sum(multiplier)#[x] for x in range(num_units) if gi[x]<=0)
        for k in range(num_districts):
            if flb+subobj[k]>max_exclusion_list[k] and subobj[k]<0:max_exclusion_list[k]=flb+subobj[k] #???
            if flb+subobj[k]>ub:
                if k not in exclusion: exclusion.append(k)
            if flb-subobj[k]>ub:
                if k not in inclusion: inclusion.append(k)
            if flb-subobj[k]>max_inclusion_list[k] and subobj[k]<0: max_inclusion_list[k]=flb-subobj[k] #???

        num=sum(1 for x in subobj if x<0)
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<0)
        if num!=max_num_facility:
            select_LR_facility()
        else:
            for k in range(num_districts):
                if subobj[k]>0:
                    subobj[k]=0.0
                    yj[k]=0
                    xij[k]=[0.0 for x in range(num_units)]
        for i in range(num_units):
            g=1.0
            for k in range(num_districts):
                g-=xij[k][i]
            gi[i]=g
        #flb=sum(subobj)+sum(multiplier)
        norm=sum(gi[x]*gi[x] for x in range(num_units))
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
        if total_supply>=total_pop-0.00001:
            best_lb_list.append([norm,yj[:],copy.deepcopy(xij)])
            best_lb_list.sort(key=lambda x: x[0])
            if len(best_lb_list)>10: del best_lb_list[-1]
        #print total_supply
        improved_lb+=1
        if flb>lb+0.0000001:
            lb=flb
            improved_lb=0
            d=sum(old_gi[x]*gi[x] for x in range(num_units))
        if improved_lb%15==14:
            alpha*=0.66
        cap=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
        cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
        if (improved_lb==0 or improved_lb%20==0) and loop>=20:
            if improved_lb==0 and cap>total_pop:
                upper_bound_CKFLP(yj,xij)
                #print "*",
            else:
                if len(best_lb_list)>0:
                    r=random.random()
                    idx=int(r*r*0.999*len(best_lb_list))
                    idx=0
                    upper_bound_CKFLP(best_lb_list[idx][1],best_lb_list[idx][2])
                    del best_lb_list[idx]
                    #print "#",
            all_solutions.append([biobjective,centersID[:],node_groups[:],objective,objective_fcost,objective_overload,max(0,total_pop-objective_supply)])
            fub=biobjective
            nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
            cap=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
            cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
            improved_ub+=1
            if fub<ub:
                ub=fub
                unf=nf
                alpha*=1.1
                improved_ub=0
        #update multiplier	
        sq=sum(x*x for x in gi)
        if abs(sq)<0.001:
            break
        t=alpha*(ub-flb)/sq
        for i in range(num_units):
            multiplier[i]+=t*gi[i]
            if multiplier[i]<0.0:
                multiplier[i]=0.0
        viol=sum(1 for x in gi if abs(x)>0.5)
        s=str(loop)+" bestub: "+str(unf)+" "+str(int(ub)) + " ub: "+str(int(fub))
        s+=" bestlb: " +str(int(lb)) + " lb: " +str(sum(yj))+" " +str(int(flb))
        #s+=" bestlb: " +str(int(lb)) + " lb: " +str(sum(yj))+" "+str(viol)+" " + str(int(norm))+" "
        #s+=str(int(flb)) +" "+ str(cap)+" " +str(int(alpha*100000)/100000.0) +" "+str(len(exclusion))
        arcpy_print(s)
        if abs(lb-ub)/ub<delta1:
            break
        if improved_lb>=300: 
            break
    all_solutions.sort(key=lambda x:x[3]+x[4]+x[5]*2*avg_dis_min+x[6]*pop_dis_coeff*avg_dis_min)
    #all_solutions.sort(key=lambda x:x[0])
    all_solutions=pop_selection(all_solutions)
    while len(all_solutions)>multi_start_count*2: all_solutions.pop()
    #while len(all_solutions)>5: all_solutions.pop()
    #spatial_contiguity=spatial_contiguity_tmp

def select_LR_facility():
    global subobj
    global yj
    global xij
    rlist=[[x,subobj[x],facilityCapacity[x],0.0 ] for x in range(num_districts) if yj[x]==1]
    rlist.sort(key=lambda x: x[1])
    if adaptive_number_of_facilities==1:
        klist=[x[0] for x in rlist if x[1]<0]
        random.shuffle(klist)
        clist=[x[0] for x in rlist if x[1]>=0]
        random.shuffle(clist)
        supply=sum(facilityCapacity[x] for x in klist)
        for x in klist:
            succ=0
            for y in clist:
                if supply-facilityCapacity[x]+facilityCapacity[y]>=total_pop:
                    klist.remove(x)
                    klist.append(y)
                    succ=1
                    break
            if succ==1: break
        for k in range(num_districts):
            if k in klist:
                yj[k]=1
            else:
                yj[k]=0
                subobj[k]=MAXNUMBER
        #print klist,sum(facilityCapacity[x] for x in klist),sum(facilityCost[x] for x in klist)
        return subobj,yj,xij
        
    klist1=[rlist[x][0] for x in range(max_num_facility)]
    supply=sum(facilityCapacity[x] for x in klist1)
    #print supply,
    if supply>=total_pop:
        for k in range(num_districts):
            subobj[k]=min(0.0,subobj[k])
            if yj[k]==0: continue
            if k not in klist1:
                yj[k]=0
                #subobj[k]=0.0
                for i in range(num_units):
                     xij[k][i]=0.0
        return subobj,yj,xij

    rlist.sort(key=lambda x: -x[2])
    flist=[x[0] for x in rlist]
    klist=[rlist[x][0] for x in range(max_num_facility)]
    #obj=sum(subobj[x] for x in klist)
    rlist.sort(key=lambda x: x[1])
    while 1:
        imp=0
        supply=sum(facilityCapacity[x] for x in klist)
        for k1 in flist:
            if k1 not in klist: continue
            for k2 in flist:
                if k2 in klist: continue
                if supply -facilityCapacity[k1]+facilityCapacity[k2]<min(total_pop,supply): continue
                if subobj[k2]<subobj[k1]:
                    #print ".",
                    klist.remove(k1)
                    klist.append(k2)
                    imp=1
                    supply=sum(facilityCapacity[x] for x in klist)
                    k1=k2
        if imp==0:
            break
        break
    #random.shuffle(rlist)
    supply=sum(facilityCapacity[x] for x in klist)
    #print supply

    for k in range(num_districts):
        subobj[k]=min(0.0,subobj[k])
        if yj[k]==0: continue
        if k not in klist:
            yj[k]=0
            xij[k]=[0.0 for i in range(num_units)]
    s=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
    c=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
    #print s,c,
    return subobj,yj,xij

def sub_CKFLP_LR(idx):
    udlist=[[i,(nodedik[i][idx]-multiplier[i])/nodes[i][3]] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    udlist.sort(key=lambda x: x[1])
    demand=0
    xlist=[0.0 for i in range(num_units)]
    f=0.0
    alpha=1.0
    if location_problem==2:
        alpha=1.0+pop_deviation
    if location_problem==1:
        f=facilityCost[idx]
    for x in udlist:
        u=x[0]
        if demand+nodes[u][3]<=facilityCapacity[idx]*alpha:
            demand+=nodes[u][3]
            xlist[u]=1.0
            f+=nodedik[u][idx]-multiplier[u]
        else:
            xlist[u]=(facilityCapacity[idx]*alpha-demand)*1.0/nodes[u][3]
            f+=(nodedik[u][idx]-multiplier[u])*xlist[u]
            break
    #demand=sum( nodes[x][3]*xlist[x] for x in range(num_units) )
    #if demand > facilityCapacity[idx]:
    #    print "debug", idx, facilityCapacity[idx], demand, xlist
    #if f>=0.0:
    #    return 0.0,0,[0 for i in range(num_units)]
    return f,1,xlist

def CFLP_CKFLP_model(numf,rand,maxtime,mipgap): #CFLP_CKFLP, i.e. split-demand 
    global node_groups
    global centersID
    global num_districts
    global district_info
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts): 
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, None, pulp.LpInteger) #
            if rand==0:
                costs["x_" +str(i)+ "_"+ str(j)]=nodedik[i][j]/nodes[i][3]
            else:
                costs["x_" +str(i)+ "_"+ str(j)]=nodedik[i][j]/nodes[i][3] *(random.random()+49.5)/50
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        if rand==0:
            costs["y_" +str(i)]=facilityCost[i]
        else:
            costs["y_" +str(i)]=facilityCost[i]*(random.random()+49.5)/50
    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0:
                obj += costs[y]*yvariables[y]
    #for x in hvariables:
    #    obj+=alpha_coeff*hvariables[x]
    prob +=obj


    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if adaptive_number_of_facilities==0:
        prob +=s == numf
    #else:
    #    prob += s<=numf 
	
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == nodes[i][3]
    for i in range(num_units):
        for j in range(num_districts):
            s=xvariables["x_" +str(i)+ "_"+ str(j)] - nodes[i][3] *yvariables["y_" + str(j)]
            prob +=s <= 0

    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=xvariables["x_" +str(i)+ "_"+ str(k)]
        #s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k]*(1+pop_deviation) * yvariables["y_" +str(k)]
        prob+=s <= 0
    s=""
    for k in range(num_districts): #for better relaxation only
        s+=facilityCapacity[k]*(1+pop_deviation)*yvariables["y_" +str(k)]
    prob+=s >= total_pop
    #selected supply unit must be assigned to itself
    #for k in range(num_districts):
    #    s=xvariables["x_" +str(facilityCandidate[k]) + "_"+ str(k) ] - nodes[facilityCandidate[k]][3]*yvariables["y_" +str(k)]
    #    prob+=s == 0
        
    #prob.writeLP("_location2.lp")
    solver=""
    if mip_solver=='cbc':
        solver=pulp.apis.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,gapRel =mipgap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        solver=pulp.apis.cplex_api.CPLEX_CMD(mip=1,msg=solver_message,timeLimit=maxtime, options=['set mip tolerances mipgap ' +str(mipgap)])
    if mip_solver=='gurobi':
        solver=pulp.apis.GUROBI_CMD(mip=1,msg=solver_message,timeLimit=maxtime,options=[("MIPGap",mipgap),("TimeLimit",maxtime)])
    solver.setTmpDir()
    solver.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        arcpy_print("MIP solver status: " + str(prob.status))
        return -1

    cid=[]
    sol=[[-1,-1] for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.50):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                cid.append(i)
                #print v,v.varValue
                continue
            if items[0]=="h": continue
            k=int(items[2])
            if v.varValue>sol[i][1]:
                sol[i][0]=k
                sol[i][1]=v.varValue
    
    centersID=facilityCandidate[:]
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
    for i in range(num_units):
        node_groups[i]=sol[i][0]
    update_district_info()
    return prob.status

def CFLSAP_mst():
    vars=[]
    for k in range(num_districts):
        v='z_'+ str(k)
        if k in node_groups:
            vars.append([v,1])
        else:
            vars.append([v,0])
    for i in range(num_units):
        for k in range(num_districts):
            v='y_'+str(i)+ '_'+ str(k)
            if k==node_groups[i]: 
                vars.append([v,1])
            else:
                vars.append([v,0])
    return vars

def mip(numf,problem_type,contiguity,timelimit):
#numf: for CKFLP, PMP only
#problem_type: 0 SAP/GAP, 1 Location Problems, 2 PDP (reserved)
#contiguity:-1 split, 0 non-contiguity, 1 contiguity
    global heuristic_time_limit
    global max_num_facility
    global spatial_contiguity
    global num_districts
    global facilityCandidate
    global nodedij
    global nodedik
    global node_groups
    global centersID
    global all_solutions
    global facilityCost
    spatial_contiguity=contiguity
    initialize_instance()
    max_num_facility=numf
    heuristic_time_limit=timelimit
    sta=0
    if problem_type==0 and contiguity==0: #GAP
        sta=GAP_model(0,heuristic_time_limit,0.000000001) 
    if problem_type==0 and contiguity==1: #SAP
        #sta=GAP_model(1,heuristic_time_limit,0.005)
        #repare_fragmented_solution()
        #VND_local_search()
        #ils(max_num_facility,multi_start_count,heuristic_time_limit,1, -1)
        multi_exchange(max_num_facility,multi_start_count,heuristic_time_limit,-1)
        sta=SAP_model() 
    if problem_type==1 and contiguity==0: #SSCFLP,SSCKFLP
        #LR_main(1000)
        cost_multipler=10
        #for i in range(num_districts): facilityCost[i]*=cost_multipler
        #multi_exchange(max_num_facility,multi_start_count,heuristic_time_limit,-1)
        location_sub_mip(max_num_facility,multi_start_count,heuristic_time_limit,-1)
        print "SSCFLP_SSCKFLP_model(max_num_facility,0,heuristic_time_limit, 0.0000000001)"
        sta=SSCFLP_SSCKFLP_model(max_num_facility,0,heuristic_time_limit, 0.0000000001)
        #check solution
        nearlist=[-1 for x in range(num_units)]
        s="facility nearest index: "
        for i in range(num_units):
            k=node_groups[i]
            idx=NearFacilityList[i].index(k)
            nearlist[i]=idx
            s+=str(idx)+" "
        arcpy_print(s)
        s= "max: "+str(max(nearlist)) +" average: "+ str(sum(nearlist)*1.0/num_units)
        arcpy_print(s)
        not_opt_cands=[]
        s="facilities must excludeded in optimal solution: "
        for k in range(num_districts): 
            if max_exclusion_list[k] >biobjective+0.0000001:
                not_opt_cands.append(k)
                s+=str(k)+ " "
        arcpy_print(s)
        must_opt_cands=[]
        s="facilities must includeded in optimal solution: "
        for k in range(num_districts): 
            if max_inclusion_list[k] >biobjective+0.0000001:
                must_opt_cands.append(k)
                s+=str(k)+ " "
        arcpy_print(s)

        s="index of optimal facilities in exclusion_list: "
        clist=[[x,max_exclusion_list[x]] for x in range(num_districts)]
        clist.sort(key=lambda x: x[1])
        clist=[x[0] for x in clist]
        idxlist=[]
        for i in range(num_districts):
            k =centersID[i]
            if k <0: continue
            idx=clist.index(i)
            idxlist.append(idx)
        idxlist.sort()
        s+= str(idxlist)
        arcpy_print(s)

        s="index of optimal facilities in inclusion_list: "
        clist=[[x,max_inclusion_list[x]] for x in range(num_districts)]
        clist.sort(key=lambda x: -x[1])
        clist=[x[0] for x in clist]
        idxlist=[]
        for i in range(num_districts):
            k =centersID[i]
            if k <0: continue
            idx=clist.index(i)
            idxlist.append(idx)
        idxlist.sort()
        s+= str(idxlist)
        arcpy_print(s)
    if problem_type==1 and contiguity==1: #CKFLP,SSCFLP with contiguity
        #if mip_solver=="cplex" or mip_solver=="cbc" :
        multi_exchange(numf,multi_start_count,heuristic_time_limit,-1)
        sta=CFLSAP_model(max_num_facility)
    if problem_type==2: #PDP
        multi_exchange(numf,multi_start_count,heuristic_time_limit,-1)
        if num_districts>=500 and num_units==len(facilityCandidate):
            cid=[]
            for x in all_solutions:
                cid+=[y for y in x[1] if y>=0]
            cid=list(set(cid))
            flist=cid[:]
            for x in cid:
                flist+=node_neighbors[x]
            flist=list(set(flist))
            flist.sort()
            facilityCandidate=flist
            for idx in range(num_districts): 
               k=num_districts-idx-1
               if k in flist: continue
               for i in range(num_units):
                   del nodedij[i][k]
                   del nodedik[i][k]
            num_districts=len(flist)
            for i in range(num_units):
                k=node_groups[i]
                node_groups[i]=flist.index(k)
            s="selected facility centers: "+str(num_districts)
            arcpy_print(s)
        sta=CFLSAP_model(max_num_facility)
    if problem_type==3 and contiguity==0: #pmp (m=n)
        sta=pmp_model(numf,heuristic_time_limit,0.0000000001)
        #sta=check_solution_continuality_feasibility(node_groups)
        #print "Areal continuality(1 yes, 0 no):",sta
    if problem_type==3 and contiguity>=1: #pmp (m=n)
        ils_pmp(numf,multi_start_count,heuristic_time_limit,-1)
        # cid=centersID[:]
        # cid=list(set(cid))
        # cid.remove(-1)
        # centersID=cid[:]
        # facilityCandidate=cid
        # flist=cid
        # for idx in range(num_districts): 
            # k=num_districts-idx-1
            # if k in flist: continue
            # for i in range(num_units):
                # del nodedij[i][k]
                # del nodedik[i][k]
        # num_districts=len(flist)
        # for i in range(num_units):
            # k=node_groups[i]
            # node_groups[i]=flist.index(k)
        # print "facilityCandidate",facilityCandidate
        # print "node_groups", set(node_groups)
        sta=CFLSAP_model(max_num_facility) 
    if sta<=0:
        return "model unsilved!"
    if spatial_contiguity==1:
        sta=check_solution_continuality_feasibility(node_groups)
        print "Areal continuality(1 yes, 0 no):",sta
        if sta<=0:
            arcpy_print("infeasible solution on continuality")
            return [-1,-1,-1,-1] #"infeasible solution on continuality"
    if -1 in node_groups:
        arcpy_print("some units are not assigned")
        return [-1,-1,-1,-1,[]]
    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    if spatial_contiguity==1  and check_solution_continuality_feasibility(best_solution_global)==0:
        arcpy_print("infeasible solution on continuality!")
        return [-1,-1,-1,-1,[]] #"infeasible solution on continuality"
    if -1 in node_groups:
        arcpy_print("some units not assigned!")
        return [-1,-1,-1,-1,[]] #"infeasible solution on continuality"
    all_solutions.append([biobjective,centersID[:],node_groups[:]])
    all_solutions.sort(key=lambda x:x[0])
    if location_problem>=2 or spatial_contiguity==1:
        sta=check_solution_continuality_feasibility(node_groups)
        print "Areal continuality(1 yes, 0 no):",sta

    return [biobjective, objective, objective_overload, centersID, node_groups]


def spp_mst():
    vars=[]        
    num_pool=len(region_pool)
    for k in range(num_districts):
        ulist=[x for x in range(num_units) if all_solutions[0][2][x]==k] 
        for i in range(num_pool):
            if ulist==region_pool[i][0] and region_pool[i][4]==k:
                vars.append([i,1])
                break
    return vars

def sppmodel(maxtime,mipgap):
    global node_groups
    global centersID
    if mip_solver not in mip_solvers:
        return 0
    if len(region_pool)<=10:
        ##noprint "no candidate district!"
        print "len(region_pool)<=10", len(region_pool)
        return 0
    alpha_coeff=avg_dis_min*pop_dis_coeff  
    prob = pulp.LpProblem("sdp_spp",pulp.LpMinimize)
    variables=[]
    costs=[]
    ###noprint "buiding spp model..."
    #cost_stat=[]
    #cost_sum=[[0,0.0,0.0] for k in range(num_districts)]
    #for x in region_pool: print x
    for i in range(len(region_pool)):
        x=pulp.LpVariable("x_" +"{0:07d}".format(i), 0, 1,pulp.LpBinary)
        variables.append(x)
        cost=region_pool[i][1]+region_pool[i][3]*alpha_coeff
        k=region_pool[i][4]
        c2=sum(nodedik[x][k] for x in region_pool[i][0])
        if abs(c2-cost)>0.001: print "check...", i,k,c2,cost,region_pool[i][1],region_pool[i][3]
        if fixed_cost_obj==1: ##[ulist,dis,demand,overload,k]
            cost+=facilityCost[k]
        costs.append(cost)
        #cost_stat.append(cost/region_pool[i][2])
        #cost_sum[k][0]+=1
        #cost_sum[k][1]+=cost/region_pool[i][2]
    #for k in range(num_districts):
    #    if cost_sum[k][0]>0:
    #        cost_sum[k][2]=cost_sum[k][1]/cost_sum[k][0]

    obj=""
    for i in range(len(region_pool)):
        obj+=costs[i]*variables[i]
    prob+=obj
    #for i in range(len(region_pool)):
    #    k=region_pool[i][4]
    #    if cost_stat[i]>cost_sum[k][2]:
    #        prob+= variables[i]==0

    rlist=[[] for i in range(num_units)]
    for j in range(len(region_pool)):
        for x in region_pool[j][0]:
            rlist[x].append(j)
    for i in range(num_units):
        s=""
        for x in rlist[i]:
            s+=variables[x]
        if spatial_contiguity==0:
            prob+=s >= 1
        else:
            prob+=s == 1
    if spatial_contiguity==0:
        for k in range(num_districts):
            s=""
            for i in range(len(region_pool)):
                if region_pool[i][4]!=k: continue
                s+=variables[i]
            if len(s)>0: prob+=s <= 1

    if adaptive_number_of_facilities==0:
        s=""
        for i in range(len(variables)):
            s+=variables[i]
        prob+= s==max_num_facility
    prob.writeLP("_spp.lp")
    #mip_mst_file=tempfile.mkstemp()[1].split("\\")[-1]

    vars=spp_mst()
    for x,v in vars: variables[x].setInitialValue(v)
    solver=0
    if mip_solver=='cbc': #solver_message #'set emphasis mip 3','set threads 4', 
        solver=pulp.apis.COIN_CMD(timeLimit=maxtime,mip=1,msg=solver_message,gapRel=mipgap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex': #solver_message #'set emphasis mip 3','set threads 4', 
        solver=pulp.apis.cplex_api.CPLEX_CMD(msg=solver_message,warmStart=True,timeLimit=maxtime,options=['set parallel -1','set mip tolerances mipgap ' + str(mipgap)])
    if mip_solver=='gurobi': #solver_message #'set emphasis mip 3','set threads 4', 
        solver=pulp.apis.GUROBI_CMD(msg=solver_message,warmStart=True,options=[("MIPGap",mipgap),("TimeLimit",maxtime)])
    solver.setTmpDir() #=mip_file_path
    solver.actualSolve(prob)
    #if os.path.isfile(mip_mst_file): os.remove(mip_mst_file)
    if prob.status<0:
       print "prob.status<0..."
       return prob.status #failer
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_districts)]
    for v in prob.variables():
        if (v.varValue >= 0.99):
            items=v.name.split('_')
            i=int(items[1])
            k=region_pool[i][4]
            #print k,costs[i],facilityCost[k]
            centersID[k]=facilityCandidate[k]
            for x in region_pool[i][0]:
                node_groups[x]=k
    a=[ x for x in centersID if x>=0]
    print "spp locs:",len(a),a
    update_district_info()
    #for i in range(num_districts): 
    #    if district_info[i][1] >0: print i,district_info[i],facilityCost[i]
    #print 
    return 1 #success
        
def pop_selection(population):
    population1=copy.deepcopy(population)
    population1.sort(key=lambda x:x[0])
    population2=[] #delete identical solution
    #sol=[best_biobjective_global,best_centersID_global[:],best_solution_global[:],best_objective_global,best_objective_fcost_global,best_overload_global,0]
    #population2.append(copy.deepcopy(sol))
    population2.append(copy.deepcopy(population1[0]))
    sdiff=1
    for x in population1:
        issimilar=0
        for y in population2:
            rlist=[i for i in range(num_districts) if x[1][i] != y[1][i]]
            if len(rlist)>=sdiff: continue
            else:
                if location_problem>=1:
                    issimilar=1
                    break
            ulist=[i for i in range(num_units) if x[2][i] != y[2][i]]
            #diffpop=sum(nodes[i][3] for i in ulist)
            #if len(ulist)<min(num_units*1.0/num_districts,num_units/30.0) and diffpop*100.0/total_pop < min(3.0,100.0/num_districts): #100.0/num_districts: #<5%
            #print len(ulist),
            if len(ulist)<num_units*(solution_similarity_limit/100.0):
                issimilar=1
                break
        if issimilar==0:
            population2.append(copy.deepcopy(x))
        if len(population2)>=multi_start_count*2:
            break
    return population2


def initial_location_solution(idx):
    global node_groups
    global centersID
    global max_exclusion_list
    global max_inclusion_list
    max_exclusion_list=[0.0 for x in range(num_districts)]
    max_inclusion_list=[0.0 for x in range(num_districts)]
    centersID=facilityCandidate[:]
    mthd=initial_solution_method
    if mip_solver not in mip_solvers: mthd=9
    sta=1
    if mthd not in [0,1,8,9]: mthd=9
    if mthd==0:
        location_construction_random()
        #location_construction_drop()
        #if location_problem==1 and len(facilityCandidate)<num_units: location_construction_random()
        #if location_problem==1 and len(facilityCandidate)==num_units: 
        #    centers=k_means()
        #    centersID=[-1 for x in range(num_districts)]
        #    for x in centers: centersID[x]=x
        #    update_district_info()
        #    print biobjective,objective,centers
        #if location_problem==2: location_construction_random()
    if mthd==1:
        sta=CFLP_CKFLP_model(max_num_facility,1,heuristic_time_limit,0.005)
    if mthd==2:
        sta=SSCFLP_SSCKFLP_model(max_num_facility,1,heuristic_time_limit,0.005)
    #if mthd==3: sta=k_medoids()
        #sta=k_means()
    if mthd==8: location_construction_LP() #not used
    if mthd==9:
        sta=LR_main(1000)
        #contiguity
        return 1
    if sta<1:
        location_construction_drop()
    if spatial_contiguity>=1:
        repare_fragmented_solution()        
    return 1
def delete_empty_facility():
    global centersID
    for k in range(num_districts):
        if k not in node_groups:
            centersID[k]=-1

def location_construction_LP():
    lplocs,sol=location_model_linear_relexation(max_num_facility,0,10000,0.01)
    relax_location=[[x,lplocs[x]] for x in range(num_districts)]
    relax_location.sort(key=lambda x:-x[1])
    #print 'relax_location',lplocs
    global node_groups
    global centersID
    centersID=[-1 for x in range(num_districts) ]
    total_supply=0
    for x in relax_location: 
        k=x[0]
        centersID[k]=facilityCandidate[k]
        total_supply+=facilityCapacity[k]
        if total_supply>=total_pop: break
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    update_district_info()
    RRT_local_search()

def location_construction_random():
    global node_groups
    global centersID
    centersID=[-1 for x in facilityCandidate]
    supply=0
    while 1:
        idx=random.randint(0,num_districts-1)
        if centersID[idx]>=0: continue
        centersID[idx]=facilityCandidate[idx]
        supply+=facilityCapacity[idx]
        nf=sum(1 for x in centersID if x>=0)
        if nf==max_num_facility and adaptive_number_of_facilities==0: break
        if supply>=total_pop and adaptive_number_of_facilities==1: break
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    update_district_info()
    for i in range(2):
        if location_problem==2: 
            if all_units_as_candadate_locations==1: update_centers()
    VND_local_search()
    return 1
def location_construction_drop(): #drop the facility that cost can be reduced
    global node_groups
    global centersID
    centersID=facilityCandidate[:]
            
    #assign to nearest facility
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            break
    delete_empty_facility()
    update_district_info()
    sta=1
    while sta==1:
        sta=r_r_location_drop_greedy()
        RRT_local_search()
def p_worst():
    global node_groups
    global centersID
    u=random.randint(0,num_districts-1)
    centers=[u]
    while 1:
        if len(centers)==max_num_facility: break
        clist=[[-1, 0.0]]
        for k in range(num_districts):
            if k in centers: continue
            cbest=min(nodedik[k][x] for x in centers)
            if cbest>clist[-1][1]:
                clist.append([k, cbest])
                clist.sort(key=lambda x: -x[1])
                if len(clist)>4: clist.pop()
        idx=random.randint(0,3)
        k=clist[idx][0]
        centers.append(k)
    centersID=[-1 for x in range(num_units)]
    for x in centers: centersID[x]=x
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    update_district_info()
    update_centers()

def generate_initial_solution():
    global best_biobjective_global
    global node_groups
    global centersID
    global all_solutions
    global tabu_list_homoDP
    solutions=[]
    t_begin=time.time()
    if location_problem==3 and initial_solution_method==8:
        if len(tabu_list_homoDP)<1:
            tabu_list_homoDP=[[] for x in range(num_districts)]
        sample_size=max(10*max_num_facility, num_units/20)
        if sample_size>num_units: sample_size=num_units
        #num_samplling=5*num_units/sample_size
        num_samplling=multi_start_count
        #if num_samplling<multi_start_count: num_samplling=multi_start_count
        pmp_sampling_solution(num_samplling,sample_size)
        return all_solutions
    if initial_solution_method==9:
        initial_solution(0)
        best_biobjective_global=MAXNUMBER  #
        for x in all_solutions: solutions.append(copy.deepcopy(x))#solutions=all_solutions
        if spatial_contiguity>=1:
            best_biobjective_global=MAXNUMBER
            for i in range(len(solutions)):
                location_check(0)
                node_groups=solutions[i][2][:]
                centersID=solutions[i][1][:]
                update_district_info()
                repare_fragmented_solution()
                VND_local_search()
                location_check(1)
                update_best_solution()
                update_region_pool_all()
                solutions[i][2]=node_groups[:]
                solutions[i][1]=centersID[:]
                solutions[i][0]=biobjective
                arcpy_print("init sol "+str(i)+" " +str(solutions[i][0]))
    if initial_solution_method!=9:
        for multi_start in range(multi_start_count):
            #random.seed(myseed+multi_start*100)
            sta=initial_solution(multi_start)
            location_check(0)
            update_best_solution()
            if spatial_contiguity>=1 and check_solution_continuality_feasibility(node_groups)<1:
                arcpy_print( "0 check_solution_continuality_feasibility(node_groups)...")
                return -1
            VND_local_search()
            location_check(1)
            if sta<0:
                arcpy_print("infeasible solution or unsolved!")
                return
            #GAP_model()
            if spatial_contiguity>=1 and check_solution_continuality_feasibility(node_groups)<1:
                arcpy_print( "1 check_solution_continuality_feasibility(node_groups)...")
                return []
            update_district_info()
            update_best_solution()
            update_region_pool_all()
            #VND_local_search()
            #three_unit_move()
            cost=objective+objective_fcost
            solutions.append([biobjective,centersID[:],node_groups[:],cost,objective_overload,0])
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
            #print best_biobjective_global,
            nf=sum(1 for x in centersID if x>=0)
            arcpy_print("initial solution "+str(multi_start+1)+": "+str(nf)+" "+str(fcost)+" "+str(biobjective)+" "+str(objective)+" "+str(objective_overload))
    arcpy_print("time for init. solutions: " + str(time.time()-t_begin))
    solutions.sort(key=lambda x:x[0])
    all_solutions=solutions
    return solutions
def initial_solution(idx):
    global node_groups
    global centersID
    global max_exclusion_list
    max_exclusion_list=[0.0 for x in range(num_districts)]
    #for FLP, PDP
    if location_problem==1: #FLP
        sta=initial_location_solution(idx) #idx
        if spatial_contiguity==1: repare_fragmented_solution()
        return sta
    if location_problem==2: #PDP
        method=initial_solution_method
        if method not in [0,9]: method=0
        if method==0: 
            kmobj,centers,sol=multi_w_k_medoids(4,100,0)
            centersID=[-1 for x in range(num_units)]
            for x in centers: centersID[x]=x
            for x in range(num_units):
                node_groups[x]=centers[sol[x]]
            update_district_info()
        if method==9: 
            CPMP_LR_main(500) #debug
        #if method==1:
        #    sta=CFLP_CKFLP_model(max_num_facility,1,heuristic_time_limit,0.005)
        if spatial_contiguity==1: repare_fragmented_solution()
        return 1
    if location_problem==3: #pmp(m=n)
        sta=-1
        method=initial_solution_method
        if method not in [0,1,8]: method=0
        if method==0: sta=k_medoids()
        if method==1: sta=p_worst()
        if method==8: sta=pmp_sampling()

        #if initial_solution_method==9:  sta=LR_main(1000) #error
        if sta==-1: arcpy_print("no initial solution!!!")
        if spatial_contiguity>=1: repare_fragmented_solution()
        #contiguity
        return 1
    if location_problem==0: #sap,gap
        method=initial_solution_method
        #if initial_solution_method==-1: method=0
        sta=1
        if method not in [0,1,9]: method=0

        node_groups=[-1 for x in range(num_units)]
        if method ==0:
            for k in range(num_districts):
                node_groups[nearCustomer[k]]=k
            region_growth()
        if method ==1:   sta=TP_model(1)
        #if method ==2:
        #    sta=GAP_model(1,heuristic_time_limit/30,0.005)
        #if method ==8:  assign_diff()
        if method ==9:
            AP_LR_main(500,0.0001,0.001)
        if spatial_contiguity==1: repare_fragmented_solution()
        return 1

def assign_diff():
    global node_groups
    caplist=[facilityCapacity[x] for x in range(num_districts)]
    ulist=[x for x in range(num_units)]
    while len(ulist)>0:
        udiff=[]
        for x in ulist:
            k1=NearFacilityList[x][0]
            k2=NearFacilityList[x][1]
            k3=NearFacilityList[x][2]
            udiff.append([x,nodedij[x][k1]*2-nodedij[x][k2]-nodedij[x][k3]])
        udiff.sort(key=lambda x:x[1])
        #loops=min(5,len(udiff)/10+1)
        #for loop in range(loops)
        idx=int(random.random()*min(3,len(udiff)))
        x=udiff[idx][0]
        assigned=0
        for r in NearFacilityList[x]:
            if nodes[x][3]<=caplist[r]:
                caplist[r]-=nodes[x][3]
                assigned=1
                node_groups[x]=r
                break
        if assigned==0: node_groups[x]=NearFacilityList[x][0]
        ulist.remove(x)
    update_district_info()

def region_growth():
    global node_groups
    loops=0
    for k in range(num_districts):
        u=centersID[k]
        node_groups[u]=k
        district_info[k][1]=nodes[u][3]
        district_info[k][2]=0.0
        district_info[k][3]=facilityCapacity[k]
    while 1:
        ulist=[x for x in range(num_units) if node_groups[x]==-1] # units not assigned
        if len(ulist)==0: break
        neighbors = []
        for x in ulist:
            for y in node_neighbors[x]:
                if node_groups[y] <0: continue
                nb=[x,node_groups[y],0.0]
                if nb not in neighbors:
                    neighbors.append(nb)
        if len(neighbors)<1: break

        if len(neighbors) ==1:
            nid=neighbors[0][0]
            rid=neighbors[0][1]
            node_groups[nid] = rid
            district_info[rid][1]+=nodes[nid][3]
            continue
        for i in range(len(neighbors)):
            nid=neighbors[i][0]
            rid=neighbors[i][1]
            gap=district_info[k][1]+nodes[nid][3]-facilityCapacity[k]*(1+pop_deviation)
            neighbors[i][2]=gap*avg_dis_min*pop_dis_coeff + nodedik[nid][rid]
        #print neighbors
        neighbors.sort(key=lambda x:x[2])
        idx=random.randint(0,1)
        nid=neighbors[idx][0]
        rid=neighbors[idx][1]
        node_groups[nid] = rid #update the solution        
        district_info[rid][1]+=nodes[nid][3]
        loops+=1
    update_district_info()

def location_check(key):
    if -1 in node_groups:
        arcpy_print("debug: "+str(key)+ " unit(s) not assigned! ")
        #return -1
    rlist=list(set(node_groups))
    if -1 in rlist: rlist.remove(-1)
    if len(rlist)>max_num_facility and adaptive_number_of_facilities==0:
        arcpy_print("debug: "+str(key)+ " too many facilities"+str(rlist))
        #return -1
    for k in range(num_districts):
        if k in rlist and centersID[k]==-1:
            arcpy_print("debug: "+str(key)+ " facilitiy not selected but used")
            #return -1
        if centersID[k]>=0 and k not in rlist:
            arcpy_print("debug: "+str(key)+ " facilitiy selected but not used")
            #return -1
        uid=centersID[k]
        if uid>-1 and node_groups[uid]!=k and spatial_contiguity==1:
            arcpy_print("debug: "+str(key)+ " facilitiy unit assigned to other facility"+str(k))
            print k,uid, node_groups[uid]
            #return -1
    #return 1

    
def print_solution():
    arcpy_print("_______________final solution_______________")
    for i in range(num_units):
        s=""
        for x in nodes[i]:
            s+=str(x)+"\t"
        k=node_groups[i]
        kunit=centersID[k]
        s+=str(nodes[kunit][4])+"\t"
        selected=-1
        if i in facilityCandidate:
            selected=0
            if i in centersID:
                selected=1
        s+=str(selected)
        arcpy_print(s)

def assign_ruin_recreate(idx):
    global time_ruin_recreate
    t=time.time()
    if idx<0 and len(ruin_oprators)<1: return -1
    ruin_idx=idx
    if idx<0:
        r=random.randint(0,len(ruin_oprators)-1)
        ruin_idx=ruin_oprators[r]
    #ruin_idx=0~4, diversification
    if ruin_idx==0: r_r_perb_location()
    if ruin_idx==1: r_r_perb_district()
    if ruin_idx==2: r_r_large_region()
    if ruin_idx==3: r_r_perb_edge_units()
    if ruin_idx==4: r_r_perb_mutation()

    #ruin_idx=5~8, intensification 
    if ruin_idx==5:
        three_unit_move_simple()
    if ruin_idx==6: r_r_pathrelink_AP() #GAP,SAP
    if ruin_idx==7:
        dlist=select_region(-1)
        tp_sub_model(dlist)
        #if spatial_contiguity==1: repare_fragmented_solution()
    if ruin_idx==8:
        dlist=select_region(-1)
        assign_sub_model(dlist)
        if spatial_contiguity==1: repare_fragmented_solution()
    if ruin_idx==9: #move a few locations for PMP, PDP
        r_r_perb_center_locations()
    if spatial_contiguity>=1: repare_fragmented_solution()
    time_ruin_recreate[ruin_idx]+=time.time()-t
    return ruin_idx,1
def r_r_perb_center_locations(): #for pmp only
    global node_groups
    global centersID
    #min_percent=10*100/max_num_facility
    #min_percent=max(min_percent,ruin_percentage)
    #percent=10
    #percent=min_percent+min_percent*random.random()
    n=random.randint(2,7)
    clist=[x for x in centersID if x>=0]
    random.shuffle(clist)
    clist=clist[:n]
    for k in clist:
        centersID[k]=-1
        r=random.random()
        idx=int(r*r*4*0.99999)
        nk=NearFacilityList[k][idx]
        #klist=node_neighbors[k][:]
        #random.shuffle(klist)
        #nk=klist[0]
        centersID[nk]=nk
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if k in centersID:
                node_groups[i]=k
                break
    update_district_info()


def MIP_location_search():
    global centersID
    old_ids=centersID[:]
    rlist=select_region(-1)
    ulist=[x for x in range(num_units) if node_groups[x] in rlist]
    sol=location_sub_model(rlist,ulist,0.0001)
    if len(sol)==0: return 0
    nlist=list(set(sol))
    nlist.sort()
    if -1 in nlist: nlist.remove(-1)
    for i in range(num_units):
        if sol[i]<0: continue
        node_groups[i]=sol[i]
    centers=set(node_groups)
    centersID=[-1 for x in range(num_districts)]
    for x in centers: centersID[x]=facilityCandidate[x]
    update_district_info()
    #if all_units_as_candadate_locations==1 or num_units==len(facilityCandidate): one_unit_move()
    return 1

def location_sub_mip(numf,multistarts,timelimit,myseed):
    global multi_start_count
    global seed
    global acceptanceRule
    global best_objective
    global best_biobjective
    global best_objective_overload
    global best_biobjective_global
    global objective
    global biobjective
    global objective_overload
    global node_groups
    global centersID
    global district_info
    global potential_facilities
    #global node_neighbors
    global move_count
    global region_pool
    global pool_index
    global is_spp_modeling
    global spp_loops
    global adj_pop_loops
    global pop_dis_coeff
    global all_solutions
    global assignment_operators_selected
    global max_num_facility
    global heuristic_time_limit
    global adjust_mutation_rate
    global large_facility_cost
    global exclusion
    global inclusion
    #global search_radius
    global initial_solution_method
    global avg_dis_min
    global spatial_contiguity
    global location_tabu_list
    global max_loops_solution_not_improved
    max_num_facility=numf
    if location_problem==0:
        max_num_facility=num_districts
    initialize_instance()
    #if mip_solver!="":
    #    lplocs,sol=location_model_linear_relexation(numf, 0,timelimit,0.0001)
    #    potential_facilities=[]
    #    for i in range(num_districts):
    #        if lplocs[i]>0.001:
    #            potential_facilities.append(i)
    #    print "potential_facilities",potential_facilities
    heuristic_time_limit=timelimit
    #evolution_stats=[]
    all_solutions=[]
    multi_start_count=multistarts
#    if multi_start_count<2: 
#        multi_start_count=2
    #is_spp_modeling=0
    seed=myseed
    if seed<0:
        seed=random.randint(0,100)
    random.seed(seed)
    arcpy_print("seed: "+str(seed))
    region_pool=[]
    t=time.time()
    ga_time=0.0
    if mip_solver not in mip_solvers:
        initial_solution_method=9
    best_biobjective_global = MAXNUMBER
    best_biobjective = MAXNUMBER
    district_info = [[0,0.0,0,0,0] for x in range(num_districts)]

    population=[] #all
    pool_index=[[] for x in range(num_districts)]
    optimum=99.99
    t_ga=time.time()
    multi_start=0
    population=generate_initial_solution()
    for x in population:
        if x[1] not in location_tabu_list:
            location_tabu_list.append(x[1][:])
    #if best_biobjective_global +0.001 < population[0][0]:
    #    print population[0][0],population[0][3],population[0][4],population[0][5],population[0][6]
    large_facility_cost=0
    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    if best_objective_fcost_global>2*best_objective_global:
        large_facility_cost=1
    avg_dis_min=(best_objective_fcost_global*fixed_cost_obj+best_objective_global)/total_pop
    if location_problem==2:
        avg_dis_min=best_objective_global/total_pop
    #print "best init solution:",population[0][0],time.time()-t_ga
    #print "large_facility_cost",large_facility_cost,fcost,best_objective_global
    #print "avg_dis_min",avg_dis_min
    if location_problem==1 and adaptive_number_of_facilities==1 and max_loops_solution_not_improved<0:
        nf=sum(1 for x in population[0][1] if x>=0)
        max_loops_solution_not_improved=max(max_loops_solution_not_improved, int(nf*multi_start_count**0.5))
        if max_loops_solution_not_improved<20: max_loops_solution_not_improved=20
    if location_problem==1 and adaptive_number_of_facilities==0 and max_loops_solution_not_improved<0:
        nf=max_num_facility
        max_loops_solution_not_improved=max(max_loops_solution_not_improved, int(nf*multi_start_count**0.5))
        if max_loops_solution_not_improved<20: max_loops_solution_not_improved=20
    s="max_loops_solution_not_improved: " +str( max_loops_solution_not_improved)
    arcpy_print(s)
    stats_mutation=[]
    ##noprint "lower_bound on obj:",lp_obj
    #t_ga=time.time()
    not_improved=0
    not_improved_global=0
    improved_time=time.time()
    loop=-1
    #print exclusion
    #print inclusion
    #print max_exclusion_list
    #print max_inclusion_list
    while 1:
        if location_problem==1 and initial_solution_method==9:
            for x in range(num_districts): 
                if max_exclusion_list[x] >best_biobjective_global: #???
                    if x not in exclusion: exclusion.append(x)
                if max_inclusion_list[x] >best_biobjective_global:
                    if x not in inclusion: inclusion.append(x)
            potential_facilities=[x for x in range(num_districts) if x not in exclusion]

        loop+=1
        r=random.random()
        sidx = int(min(multi_start_count-1,len(population))* pow(r,2)*0.999)
        r=random.random()
        node_groups=population[sidx][2][:]
        centersID=population[sidx][1][:]
        update_district_info()
        update_best_solution()
        #potential_facilities=[x for x in range(num_districts)]
        #potential_facilities=[x for x in range(num_districts) if max_exclusion_list[x] <= biobjective] #best_biobjective_global

        #search_radius=objective/total_pop ##dynamic radius to define the spatially-constrained areas!!!
        #not_improved+=1
        not_improved_global+=1
        old_ids=centersID[:]
        obj=biobjective
        tag="loc"
        idx,sta=r_r_new_location(-1)
        if sta==1: VND_local_search()
        if all_units_as_candadate_locations==1 or num_units==len(facilityCandidate): 
            update_centers()
        update_best_solution()
        update_region_pool_all()
        population.append([biobjective,centersID[:],node_groups[:],objective,objective_fcost,objective_overload,max(0,total_pop-objective_supply)])
        s=""
        if biobjective<population[0][0]*0.999999999:  #0.1%
            #not_improved_global=0
            #update_region_pool_all()
            s="*"
            impp=((biobjective-population[0][0])/biobjective)*1000 #-0.1%
            not_improved_global+=int(max_loops_solution_not_improved*impp)
            if not_improved_global<0: not_improved_global=0
            #print "*",#[biobjective,population[0][0]],
            #print [x for x in old_ids if x not in centersID],[x for x in centersID if x not in old_ids],
        elif biobjective<obj-0.0001: 
            #update_region_pool_all()
            s="#"
        else: s="-"
        s+=tag
        bnf=sum(1 for x in best_centersID_global if x>=0)
        s+="Search loop "+str(loop) + " best: " +str(bnf)+" "+str(int(best_biobjective_global))+" "+str(int(best_objective_global))+" "+str(int(best_overload_global))
        nf=sum(1 for x in centersID if x>=0)
        s+=" current: " +str(int(population[sidx][0]))+" -> "+str(nf)+" "+str(int(biobjective))+" "+str(int(objective))+" "+str(int(objective_overload))
        f=[x for x in range(num_districts) if max_exclusion_list[x] <=best_biobjective_global+0.00001]
        s+=" Info: " +str(len(population))+" "+str(not_improved_global)+ " "+str(int(time.time()-t_ga))
        minr=min(x[1] for x in district_info if x[0]>0)
        s+=" " + str(len(exclusion)) +" " + str(len(inclusion))
        arcpy_print(s)
        if not_improved_global >= max_loops_solution_not_improved: break
        population.sort(key=lambda x:x[0])
        #if adaptive_number_of_facilities>=0: population.sort(key=lambda x:x[0])
        #else: population.sort(key=lambda x:x[3]+x[4]+x[5]*2*avg_dis_min+x[6]*avg_dis_min*pop_dis_coeff)
        population=pop_selection(population)
        #if len(population2) >=multi_start_count/2 and len(population2)>=2:
        #    population=potion2
        while len(population)>multi_start_count*2:
            population.pop()
        #if loop>multi_start_count*4:#max(200,nf*5):
        #    while population[-1][0]>population[0][0]*1.02:
        #        population.pop()
        all_solutions=population
        location_check(9)
        #if time.time()-t_ga > heuristic_time_limit:  break
    #post procedure
    population.sort(key=lambda x:x[0])
    node_groups=best_solution_global[:] #population[0][2][:]
    centersID=best_centersID_global[:]
    update_district_info()
    if assign_or_Location_search_method==10:
        if 1 not in assignment_operators_selected: assignment_operators_selected.append(1)
        elif 2 not in assignment_operators_selected: assignment_operators_selected.append(2)
        VND_local_search()
        update_region_pool_all()
        node_groups=best_solution_global[:] #population[0][2][:]
        centersID=best_centersID_global[:]
        update_district_info()
        population.append([biobjective,centersID[:],node_groups[:],objective,objective_fcost,objective_overload,0])
    ga_time=time.time()-t_ga
    print "Heuristic solution:",biobjective,objective_fcost,objective,objective_overload,ga_time
    t_spp=time.time()
    if is_spp_modeling>=1:
        arcpy_print("SPP modelling..."+str(len(region_pool)) )
        sppmodel(heuristic_time_limit,0.00000001)
        update_district_info()
        update_best_solution()
        #if 1 not in assignment_operators_selected: assignment_operators_selected.append(1)
        #elif 2 not in assignment_operators_selected: assignment_operators_selected.append(2)
        VND_local_search()
        population.append([biobjective,centersID[:],node_groups[:],objective,objective_fcost,objective_overload,0])
        print "spp solution:",biobjective,objective_fcost,objective,objective_overload,time.time()-t_spp, time.time()-t_spp
    print "final solution:",biobjective,objective_fcost,objective,objective_overload
    population.sort(key=lambda x:x[0])
    all_solutions=population

    sta=check_solution_continuality_feasibility(node_groups)
    print "Areal continuality(1 yes, 0 no):",sta
    if spatial_contiguity==1 and sta==0: 
        print "infeasible final solution: continuality"
        return "infeasible final solution: continuality"
    ##noprint "time",time.time()-t
    search_stat()
    print "location_tabu_list",len(location_tabu_list)
    print "check obj:", biobjective,"==",
    update_district_info()
    print biobjective
    return [best_biobjective_global,best_objective_global,best_overload_global,centersID,best_solution_global]

def search_stat():
    arcpy_print("----------------search statistics----------------------")
    arcpy_print("one unit move, move and time: "+ str(count_op[0])+ ", " +str(time_op[0]) )
    arcpy_print("two unit move, move and time: "+ str(count_op[1])+ ", " +str(time_op[1]) )
    arcpy_print("three unit move, move and time: "+ str(count_op[2])+ ", " +str(time_op[2]) )
    arcpy_print("location swap time: "+ str(time_location[0]) )
    arcpy_print("location drop time: "+ str(time_location[1]) )
    arcpy_print("location add time: "+ str(time_location[2]) )
    arcpy_print("location multi-exchange time: "+ str(time_location[4]) )
    arcpy_print("location TB heur. time: "+ str(time_location[7]) )
    arcpy_print("location PMP sub_mip time: "+ str(time_location[8]) )
    arcpy_print("location CFLP sub_mip time: "+ str(time_location[9]) )
    arcpy_print("location PMP TB time: "+ str(time_pmp_re_location) )
    arcpy_print("repare time: "+ str(time_repare) )
    arcpy_print("update_centers time: "+ str(time_update_centers) )
    arcpy_print("spp regions: "+ str(len(region_pool)) )
    arcpy_print("spp pooling time: "+ str(time_spp) )
    arcpy_print("time for ruin and recreate: " + str(time_ruin_recreate))
    if spatial_contiguity==1:
        sta=check_solution_continuality_feasibility(best_solution_global)
        arcpy_print("solution on continuality (0 no, 1 yes) : "+str(sta))
    arcpy_print("----------------end of search statistics----------------")
